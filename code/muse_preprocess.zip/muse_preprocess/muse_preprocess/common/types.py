"""모든 파이프라인이 공유하는 결과·추적 타입."""
from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator


class RetakeRequired(Exception):
    """품질 게이트 실패. message는 사용자에게 보여줄 안내 문구."""

    def __init__(self, message: str, reason: str):
        super().__init__(message)
        self.reason = reason


@dataclass
class Trace:
    """단계별 소요 시간과 품질 플래그 기록.

    `trainable`이 False이면 화면 표시에는 쓰되 개인화 학습에서는 제외한다 (공통 원칙 3).
    """
    timings_ms: dict[str, float] = field(default_factory=dict)
    flags: dict[str, Any] = field(default_factory=dict)
    trainable: bool = True

    @contextmanager
    def stage(self, name: str) -> Iterator[None]:
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.timings_ms[name] = (time.perf_counter() - t0) * 1000.0

    def flag(self, key: str, value: Any = True, *, untrainable: bool = False) -> None:
        self.flags[key] = value
        if untrainable:
            self.trainable = False

    @property
    def total_ms(self) -> float:
        return sum(self.timings_ms.values())
