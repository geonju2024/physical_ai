"""색 처리 유틸리티.

공통 원칙 1: 색상 브랜치는 선형 연산(CCM, 백색 순응)만 적용하고,
CLAHE 같은 비선형 향상은 분석 브랜치에서만 사용한다.
"""
from __future__ import annotations

import cv2
import numpy as np
from skimage.color import deltaE_ciede2000, lab2rgb, rgb2lab
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# ---------------------------------------------------------------- 변환

def srgb_to_linear(x: np.ndarray) -> np.ndarray:
    x = np.clip(x, 0.0, 1.0)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def linear_to_srgb(x: np.ndarray) -> np.ndarray:
    x = np.clip(x, 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1 / 2.4) - 0.055)


def bgr8_to_rgb_float(img: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0


def rgb_float_to_bgr8(img: np.ndarray) -> np.ndarray:
    return cv2.cvtColor((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8), cv2.COLOR_RGB2BGR)


def bgr8_to_lab(img: np.ndarray) -> np.ndarray:
    """D65 기준 CIE Lab (L 0~100)."""
    return rgb2lab(bgr8_to_rgb_float(img))


# ---------------------------------------------------------------- 색 보정 매트릭스

_TO_LIN = srgb_to_linear(np.arange(256) / 255.0).astype(np.float32)
_TO_SRGB = (linear_to_srgb(np.arange(4096) / 4095.0) * 255 + 0.5).astype(np.uint8)


def apply_ccm(img_bgr8: np.ndarray, ccm: np.ndarray) -> np.ndarray:
    """선형 RGB 공간에서 3×3 CCM 적용. LUT + cv2.transform으로 Edge 지연 최소화."""
    lin = _TO_LIN[img_bgr8]                                  # BGR 순서 유지
    m = np.asarray(ccm, np.float32)[::-1, ::-1]              # RGB 행렬 → BGR 행렬
    out = cv2.transform(lin, m)
    idx = np.clip(out * 4095.0 + 0.5, 0, 4095).astype(np.uint16)
    return _TO_SRGB[idx]


def estimate_ccm(measured_rgb: np.ndarray, reference_rgb: np.ndarray) -> np.ndarray:
    """패치 측정값(N×3, sRGB 0~1) → 기준값(N×3)으로 가는 3×3 CCM, 선형 공간 최소제곱."""
    m = srgb_to_linear(np.asarray(measured_rgb, dtype=np.float64))
    r = srgb_to_linear(np.asarray(reference_rgb, dtype=np.float64))
    x, *_ = np.linalg.lstsq(m, r, rcond=None)
    return x.T


def patch_delta_e(rgb_a: np.ndarray, rgb_b: np.ndarray) -> np.ndarray:
    la = rgb2lab(np.asarray(rgb_a, dtype=np.float64).reshape(-1, 1, 3))
    lb = rgb2lab(np.asarray(rgb_b, dtype=np.float64).reshape(-1, 1, 3))
    return deltaE_ciede2000(la, lb).ravel()


# ---------------------------------------------------------------- 백색 순응 (센서 기반)

_BRADFORD = np.array([[0.8951, 0.2664, -0.1614],
                      [-0.7502, 1.7135, 0.0367],
                      [0.0389, -0.0685, 1.0296]])
_XYZ2RGB = np.array([[3.2406, -1.5372, -0.4986],
                     [-0.9689, 1.8758, 0.0415],
                     [0.0557, -0.2040, 1.0570]])
_RGB2XYZ = np.linalg.inv(_XYZ2RGB)
_D65_XY = (0.31271, 0.32902)


def cct_to_xy(cct: float) -> tuple[float, float]:
    """색온도 → 색도 좌표.

    4000K 미만은 플랑크 궤적(Kim et al.), 4000K 이상은 CIE 주광 궤적을 사용한다
    (자연광·주광색 LED가 섞인 가구 [B1] 기준. 6504K에서 D65와 일치).
    """
    t = float(np.clip(cct, 1667, 25000))
    if t < 4000:
        x = -0.2661239e9 / t**3 - 0.2343589e6 / t**2 + 0.8776956e3 / t + 0.179910
        if t <= 2222:
            y = -1.1063814 * x**3 - 1.34811020 * x**2 + 2.18555832 * x - 0.20219683
        else:
            y = -0.9549476 * x**3 - 1.37418593 * x**2 + 2.09137015 * x - 0.16748867
        return x, y
    if t <= 7000:
        x = -4.6070e9 / t**3 + 2.9678e6 / t**2 + 0.09911e3 / t + 0.244063
    else:
        x = -2.0064e9 / t**3 + 1.9018e6 / t**2 + 0.24748e3 / t + 0.237040
    return x, -3.0 * x**2 + 2.870 * x - 0.275


def _xy_to_xyz(x: float, y: float) -> np.ndarray:
    return np.array([x / y, 1.0, (1 - x - y) / y])


def adaptation_matrix(src_cct: float) -> np.ndarray:
    """측정 색온도 → D65 Bradford 순응을 선형 RGB 3×3 행렬로 반환."""
    src = _BRADFORD @ _xy_to_xyz(*cct_to_xy(src_cct))
    dst = _BRADFORD @ _xy_to_xyz(*_D65_XY)
    m_xyz = np.linalg.inv(_BRADFORD) @ np.diag(dst / src) @ _BRADFORD
    return _XYZ2RGB @ m_xyz @ _RGB2XYZ


def ambient_ratio(sensor_lux: float, led_lux: float) -> float:
    """사용자 위치 조도 중 LED 외 주변광이 차지하는 비율 [B1][B2]."""
    total = max(sensor_lux, 1e-6)
    return float(np.clip((total - led_lux) / total, 0.0, 1.0))


# ---------------------------------------------------------------- 분석 브랜치 향상

def clahe_l(img_bgr8: np.ndarray, clip: float, tile: int) -> np.ndarray:
    lab = cv2.cvtColor(img_bgr8, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
    lab[..., 0] = clahe.apply(lab[..., 0])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


# ---------------------------------------------------------------- 대표색 추출

def dominant_colors(lab_pixels: np.ndarray, weights: np.ndarray | None,
                    k_range: tuple[int, int], max_samples: int = 4000,
                    seed: int = 0) -> list[dict]:
    """Lab 픽셀 K-means. k는 실루엣 계수로 자동 선택. 면적(가중치) 비율 내림차순."""
    px = np.asarray(lab_pixels, dtype=np.float64).reshape(-1, 3)
    w = np.ones(len(px)) if weights is None else np.asarray(weights, dtype=np.float64).ravel()
    keep = w > 0
    px, w = px[keep], w[keep]
    if len(px) == 0:
        return []
    rng = np.random.default_rng(seed)
    if len(px) > max_samples:
        idx = rng.choice(len(px), max_samples, replace=False, p=w / w.sum())
        px, w = px[idx], np.ones(max_samples)

    n_unique = len(np.unique(np.round(px, 1), axis=0))
    best = None
    for k in range(max(2, k_range[0]), k_range[1] + 1):
        if k >= n_unique:
            break
        km = KMeans(n_clusters=k, n_init=4, random_state=seed).fit(px, sample_weight=w)
        s = silhouette_score(px, km.labels_, sample_size=min(2000, len(px)), random_state=seed)
        if best is None or s > best[0]:
            best = (s, km)
    if best is None:  # 색이 거의 하나뿐
        centers, labels = px.mean(axis=0, keepdims=True), np.zeros(len(px), int)
    else:
        centers, labels = best[1].cluster_centers_, best[1].labels_

    total = w.sum()
    out = []
    for i, c in enumerate(centers):
        share = float(w[labels == i].sum() / total)
        rgb = np.clip(lab2rgb(c.reshape(1, 1, 3)).ravel(), 0, 1)
        out.append({
            "lab": [round(float(v), 2) for v in c],
            "hex": "#{:02X}{:02X}{:02X}".format(*(int(v * 255 + 0.5) for v in rgb)),
            "ratio": round(share, 4),
            "chroma": round(float(np.hypot(c[1], c[2])), 2),
        })
    out.sort(key=lambda d: d["ratio"], reverse=True)
    return out[:3]
