"""프레임 품질 게이트: 블러, 노출 클리핑, 움직임 [C3][A10][B3]."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from ..config import QualityConfig


def _gray(img: np.ndarray) -> np.ndarray:
    return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _resize_width(img: np.ndarray, width: int) -> np.ndarray:
    h, w = img.shape[:2]
    if w <= width:
        return img
    return cv2.resize(img, (width, int(h * width / w)), interpolation=cv2.INTER_AREA)


def blur_score(img: np.ndarray, width: int = 1280) -> float:
    """Laplacian 분산. 해상도에 따라 값이 달라지므로 고정 폭으로 축소 후 계산."""
    g = _resize_width(_gray(img), width)
    return float(cv2.Laplacian(g, cv2.CV_64F).var())


def clip_ratio(img: np.ndarray) -> float:
    """완전 검정(≤2) 또는 포화(≥253) 픽셀 비율."""
    g = _gray(img)
    return float(np.mean((g <= 2) | (g >= 253)))


def motion_score(prev: np.ndarray, cur: np.ndarray) -> float:
    """프레임 간 평균 절대 차이 (0~255), 160px 폭 + 블러로 센서 노이즈 억제.

    옵티컬 플로(Farneback)는 프레임당 약 40ms로 15프레임 버스트에서 지연 예산을 넘기므로
    '움직였는가'만 판단하는 이 방식을 기본으로 쓴다.
    """
    a = cv2.GaussianBlur(_resize_width(_gray(prev), 160), (5, 5), 0).astype(np.int16)
    b = cv2.GaussianBlur(_resize_width(_gray(cur), 160), (5, 5), 0).astype(np.int16)
    return float(np.abs(a - b).mean())


@dataclass
class FrameScore:
    index: int
    blur: float
    clip: float
    motion: float

    def passes(self, cfg: QualityConfig) -> bool:
        return (self.blur >= cfg.blur_var_min and self.clip <= cfg.clip_ratio_max
                and self.motion <= cfg.motion_max)

    @property
    def rank_key(self) -> float:
        # 선명할수록, 움직임이 적을수록 우선
        return self.blur / (1.0 + self.motion) * (1.0 - self.clip)


def score_frames(frames: list[np.ndarray], cfg: QualityConfig) -> list[FrameScore]:
    scores: list[FrameScore] = []
    for i, f in enumerate(frames):
        m = motion_score(frames[i - 1], f) if i > 0 else (
            motion_score(f, frames[1]) if len(frames) > 1 else 0.0)
        scores.append(FrameScore(i, blur_score(f, cfg.blur_downsample_width), clip_ratio(f), m))
    return scores


def select_frames(frames: list[np.ndarray], cfg: QualityConfig, k: int) -> list[int]:
    """품질 게이트를 통과한 프레임 중 상위 k개의 인덱스. 통과 프레임이 없으면 빈 리스트."""
    passed = [s for s in score_frames(frames, cfg) if s.passes(cfg)]
    passed.sort(key=lambda s: s.rank_key, reverse=True)
    return [s.index for s in passed[:k]]
