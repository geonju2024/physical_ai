"""사용자 신체 이미지(RGB) 전처리 파이프라인 (제안서 1장). Edge에서 실행.

모드
  - daily   : 버튼 트리거 → 착장 인식 (목표 ≈1.1초, [C8])
  - measure : 월 1회 체형 측정 (정확도 우선, ≈5초)

[I3] 카메라 상시 대기를 거부한 가구가 있으므로 트리거는 항상 버튼이다.
이 모듈은 버튼이 눌리고 LED가 켜진 뒤 취득한 버스트 프레임을 입력으로 받는다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import cv2
import numpy as np

from ..common import color as C
from ..common.quality import select_frames
from ..common.types import RetakeRequired, Trace
from ..config import MuseConfig
from ..models.interfaces import (GARMENT_CLASSES, KP, PARSE_CLASSES, FaceBox, FaceEmbedder,
                                 HumanParser, PersonBox, PersonDetector, PoseEstimator)

Mode = Literal["daily", "measure"]


@dataclass
class DeviceCalibration:
    camera_matrix: np.ndarray
    dist_coeffs: np.ndarray
    led_ccm: np.ndarray = field(default_factory=lambda: np.eye(3))  # LED 하에서 → D65
    led_cct: float = 5000.0


@dataclass
class SensorReading:
    tof_distance_m: float
    lux: float          # 사용자 위치 조도 (LED 점등 상태)
    cct: float          # 조도·색온도 센서 측정값
    led_lux: float      # 조도 센서 피드백으로 계산한 LED 기여분


@dataclass
class GarmentCrop:
    cls: str
    image: np.ndarray       # 색상 브랜치(D65) 크롭
    mask: np.ndarray        # 크롭 크기 마스크
    visible_ratio: float    # 가림 제외 후 가시 비율 [C4]
    area_ratio: float       # 사람 마스크 대비 면적


@dataclass
class BodyResult:
    user_id: str | None
    id_status: Literal["auto", "confirm", "guest"]
    color_img: np.ndarray
    analysis_img: np.ndarray
    person_mask: np.ndarray
    parse_map: np.ndarray
    garments: dict[str, GarmentCrop]
    vton_input: np.ndarray            # 얼굴 마스킹 완료, 서버 전송 가능
    pose_input: np.ndarray
    face_box: FaceBox | None          # Edge에만 보관 (Try-On 결과 얼굴 재합성용)
    keypoints: np.ndarray | None
    measurement: dict
    trace: Trace


# ---------------------------------------------------------------- 유틸

def guided_filter(guide: np.ndarray, src: np.ndarray, r: int, eps: float) -> np.ndarray:
    """He et al. 가이디드 필터 (회색조 가이드). Jetson 기본 OpenCV에 contrib가 없어도 동작."""
    I = cv2.cvtColor(guide, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    p = src.astype(np.float32)
    box = lambda x: cv2.boxFilter(x, -1, (2 * r + 1, 2 * r + 1))
    mI, mp = box(I), box(p)
    a = (box(I * p) - mI * mp) / (box(I * I) - mI * mI + eps)
    b = mp - a * mI
    return box(a) * I + box(b)


def _cos(a: np.ndarray, b: np.ndarray) -> float:
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))


def _angle_deg(v1: np.ndarray, v2: np.ndarray) -> float:
    c = v1 @ v2 / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-9)
    return float(np.degrees(np.arccos(np.clip(c, -1, 1))))


# ---------------------------------------------------------------- 파이프라인

class BodyPipeline:
    def __init__(self, cfg: MuseConfig, calib: DeviceCalibration, detector: PersonDetector,
                 parser: HumanParser, pose: PoseEstimator, face: FaceEmbedder,
                 user_faces: dict[str, list[np.ndarray]]):
        self.cfg, self.calib = cfg, calib
        self.detector, self.parser, self.pose, self.face = detector, parser, pose, face
        self.user_faces = user_faces
        self._undistort_maps: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] = {}

    def warmup(self, shape: tuple[int, int] = (960, 720)) -> None:
        """부팅 시 1회 호출. OpenCV 첫 호출 지연(CLAHE 등 ~100ms)을 버튼 응답 시간에서 제거."""
        dummy = np.full((*shape, 3), 128, np.uint8)
        C.clahe_l(dummy, self.cfg.color.clahe_clip, self.cfg.color.clahe_tile)
        C.apply_ccm(dummy, np.eye(3))
        self.undistort(dummy)

    # 1. 거리 확인 ------------------------------------------------------
    def check_distance(self, s: SensorReading) -> None:
        c = self.cfg.capture
        if s.tof_distance_m < c.min_distance_m:
            raise RetakeRequired("한 걸음 뒤로 물러나 주세요.", "too_close")
        if s.tof_distance_m > c.max_distance_m:
            raise RetakeRequired("한 걸음 앞으로 와 주세요.", "too_far")

    # 5. 왜곡 보정 -----------------------------------------------------
    def undistort(self, img: np.ndarray) -> np.ndarray:
        h, w = img.shape[:2]
        if (w, h) not in self._undistort_maps:
            self._undistort_maps[(w, h)] = cv2.initUndistortRectifyMap(
                self.calib.camera_matrix, self.calib.dist_coeffs, None,
                self.calib.camera_matrix, (w, h), cv2.CV_16SC2)
        m1, m2 = self._undistort_maps[(w, h)]
        return cv2.remap(img, m1, m2, cv2.INTER_LINEAR)

    # 6. 색상 브랜치 ---------------------------------------------------
    def color_correct(self, img: np.ndarray, s: SensorReading, tr: Trace) -> np.ndarray:
        amb = C.ambient_ratio(s.lux, s.led_lux)
        tr.flag("ambient_ratio", round(amb, 3))
        if amb > self.cfg.color.ambient_ratio_max:
            # [B1][B2] 주변광이 LED를 압도 → 색은 표시만, 색 취향 학습 제외
            tr.flag("color_low_confidence", True)
        # 센서 CCT → LED CCT 순응 후, LED 기준 공장 CCM 적용 (모두 선형 연산)
        to_led = C.adaptation_matrix(s.cct) @ np.linalg.inv(C.adaptation_matrix(self.calib.led_cct))
        return C.apply_ccm(img, self.calib.led_ccm @ to_led)

    # 8. 타깃 선택 -----------------------------------------------------
    def select_target(self, img: np.ndarray, depth: np.ndarray | None) -> PersonBox:
        h, w = img.shape[:2]
        half = self.cfg.body.center_ratio / 2
        c = self.cfg.capture
        cands = []
        for b in self.detector.detect(img):
            cx, _ = b.center
            if abs(cx / w - 0.5) > half:
                continue
            z = None
            if depth is not None:
                roi = depth[int(b.y1):int(b.y2), int(b.x1):int(b.x2)]
                z = float(np.nanmedian(roi)) if np.isfinite(roi).any() else None
                # 깊이가 없거나 범위 밖 = 유리·TV에 비친 허상 [A7]
                if z is None or not (c.min_distance_m <= z <= c.max_distance_m):
                    continue
            cands.append((z if z is not None else 0.0, -b.score, b))
        if not cands:
            raise RetakeRequired("거울 중앙의 표시 위치에 서 주세요.", "no_target")
        cands.sort(key=lambda t: (t[0], t[1]))
        return cands[0][2]

    # 9. 사용자 식별 ---------------------------------------------------
    def identify(self, emb: np.ndarray | None) -> tuple[str | None, str, float]:
        b = self.cfg.body
        if emb is None or not self.user_faces:
            return None, "guest", 0.0
        best_id, best = None, -1.0
        for uid, embs in self.user_faces.items():
            s = max(_cos(emb, e) for e in embs)
            if s > best:
                best_id, best = uid, s
        if best >= b.face_match_auto:
            return best_id, "auto", best
        if best >= b.face_match_confirm:
            return best_id, "confirm", best
        return None, "guest", best

    # 10. 배경 분리 ----------------------------------------------------
    def separate(self, img: np.ndarray, parse: np.ndarray, depth: np.ndarray | None,
                 box: PersonBox, tr: Trace) -> np.ndarray:
        person = parse > 0
        if depth is None:
            tr.flag("no_depth_gating", untrainable=True)
            return person
        torso_ids = [GARMENT_CLASSES["upper"], GARMENT_CLASSES["outer"], GARMENT_CLASSES["dress"]]
        # 기준 깊이는 선택된 타깃 박스 안의 몸통에서만 구한다.
        # (파서가 배경 행거 옷까지 'upper'로 잡으면 전체 중앙값이 배경 쪽으로 끌려감 [A5])
        in_box = np.zeros_like(person)
        in_box[int(box.y1):int(box.y2), int(box.x1):int(box.x2)] = True
        torso = np.isin(parse, torso_ids) & np.isfinite(depth) & in_box
        ref = torso if torso.sum() > 100 else (person & np.isfinite(depth) & in_box)
        if not ref.any():
            tr.flag("no_depth_gating", untrainable=True)
            return person
        z = float(np.median(depth[ref]))
        with np.errstate(invalid="ignore"):
            gate = np.abs(depth - z) <= self.cfg.body.depth_gate_m
        # 깊이 결손 픽셀(검정 옷 등)은 파싱 결과를 신뢰
        gate |= ~np.isfinite(depth)
        mask = (person & gate).astype(np.float32)
        refined = guided_filter(img, mask, self.cfg.body.guided_radius, self.cfg.body.guided_eps)
        removed = float((person & ~gate).sum() / max(person.sum(), 1))
        tr.flag("depth_gate_removed_ratio", round(removed, 3))   # 배경 의류 오인식 제거량 [A5]
        return refined > 0.5

    # 11. 파싱 정리 ----------------------------------------------------
    def clean_parse(self, parse: np.ndarray, person: np.ndarray) -> np.ndarray:
        out = np.where(person, parse, 0).astype(np.uint8)
        total = max(int(person.sum()), 1)
        for cid in np.unique(out):
            if cid == 0:
                continue
            m = (out == cid).astype(np.uint8)
            n, labels, stats, _ = cv2.connectedComponentsWithStats(m)
            for i in range(1, n):
                if stats[i, cv2.CC_STAT_AREA] / total < self.cfg.body.min_part_area_ratio:
                    out[labels == i] = 0
        return out

    # 12. 포즈 유효성 (측정 모드) ---------------------------------------
    def check_pose(self, kps: np.ndarray, view: Literal["front", "side"]) -> None:
        b = self.cfg.body
        # 얼굴 키포인트(0~4)는 머리카락·모자 가림을 허용하고 몸통·팔다리(5~16)만 검사
        low = int((kps[5:, 2] < b.joint_conf_min).sum())
        if low > b.max_low_conf_joints:
            raise RetakeRequired("몸 전체가 화면에 보이도록 서 주세요.", "low_conf_joints")
        if view == "front":
            lo, hi = b.arm_angle_range
            for s, e in (("l_shoulder", "l_elbow"), ("r_shoulder", "r_elbow")):
                sh, el = kps[KP[s], :2], kps[KP[e], :2]
                hip = kps[KP["l_hip" if s[0] == "l" else "r_hip"], :2]
                ang = _angle_deg(el - sh, hip - sh)
                if not (lo - b.arm_angle_tol <= ang <= hi + b.arm_angle_tol):
                    raise RetakeRequired("팔을 몸에서 살짝 벌려 주세요.", "arm_angle")

    # 13. 가림 처리 (측정 모드) -----------------------------------------
    def occlusion(self, kps: np.ndarray | None, parse: np.ndarray, person: np.ndarray,
                  depth: np.ndarray | None, tr: Trace) -> dict:
        b = self.cfg.body
        info: dict = {}
        total = max(int(person.sum()), 1)
        bag_ratio = float((parse == GARMENT_CLASSES["bag"]).sum() / total)
        if bag_ratio > b.bag_area_max:
            raise RetakeRequired("가방을 내려놓고 다시 서 주세요.", "bag")
        if (parse == 1).any():
            tr.flag("hat_present")       # 정수리는 깊이 윤곽으로 추정
        if kps is not None and depth is not None:
            ls, rs = kps[KP["l_shoulder"]], kps[KP["r_shoulder"]]
            if min(ls[2], rs[2]) < b.joint_conf_min:
                # 머리카락에 가려진 어깨 → 깊이 마스크 윤곽 폭으로 어깨폭 추정 [C4]
                y = int(np.clip((ls[1] + rs[1]) / 2, 0, person.shape[0] - 1))
                xs = np.nonzero(person[y])[0]
                if len(xs) > 1:
                    z = float(np.nanmedian(depth[y, xs])) if np.isfinite(depth[y, xs]).any() else np.nan
                    fx = self.calib.camera_matrix[0, 0]
                    info["shoulder_width_m_depth"] = float((xs[-1] - xs[0]) * z / fx)
                    tr.flag("shoulder_from_depth")
        return info

    # 14. 신발 보정 ----------------------------------------------------
    def footwear_offset(self, footwear: str | None, parse: np.ndarray, mode: Mode,
                        tr: Trace) -> float:
        offsets = self.cfg.body.footwear_offset_cm
        has_shoes = bool((parse == GARMENT_CLASSES["shoes"]).any())
        if footwear is None:
            footwear = "sneakers" if has_shoes else "barefoot"
            if has_shoes:
                tr.flag("footwear_assumed", footwear)
        if mode == "measure" and footwear not in ("barefoot", "socks"):
            tr.flag("guide_barefoot")    # 다음 측정 때 맨발 안내
        return offsets.get(footwear, offsets["sneakers"])

    # 15·16. 익명화와 정규화 -------------------------------------------
    def anonymize(self, img: np.ndarray, face: FaceBox | None) -> np.ndarray:
        out = img.copy()
        if face is None:
            return out
        e = self.cfg.body.face_bbox_expand
        w, h = face.x2 - face.x1, face.y2 - face.y1
        x1, y1 = max(0, int(face.x1 - w * e / 2)), max(0, int(face.y1 - h * e / 2))
        x2 = min(img.shape[1], int(face.x2 + w * e / 2))
        y2 = min(img.shape[0], int(face.y2 + h * e / 2))
        out[y1:y2, x1:x2] = 128
        return out

    def crop_resize(self, img: np.ndarray, mask: np.ndarray, size: tuple[int, int]) -> np.ndarray:
        ys, xs = np.nonzero(mask)
        if len(xs) == 0:
            return cv2.resize(img, size, interpolation=cv2.INTER_AREA)
        m = self.cfg.body.crop_margin
        x1, x2, y1, y2 = xs.min(), xs.max(), ys.min(), ys.max()
        bw, bh = x2 - x1, y2 - y1
        x1, x2 = max(0, int(x1 - bw * m)), min(img.shape[1], int(x2 + bw * m))
        y1, y2 = max(0, int(y1 - bh * m)), min(img.shape[0], int(y2 + bh * m))
        crop = img[y1:y2, x1:x2]
        # 비율 유지 + 패딩
        tw, th = size
        s = min(tw / crop.shape[1], th / crop.shape[0])
        r = cv2.resize(crop, (max(1, int(crop.shape[1] * s)), max(1, int(crop.shape[0] * s))),
                       interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR)
        canvas = np.full((th, tw, 3), 255, np.uint8)
        oy, ox = (th - r.shape[0]) // 2, (tw - r.shape[1]) // 2
        canvas[oy:oy + r.shape[0], ox:ox + r.shape[1]] = r
        return canvas

    def garment_crops(self, img: np.ndarray, parse: np.ndarray, person: np.ndarray
                      ) -> dict[str, GarmentCrop]:
        out = {}
        total = max(int(person.sum()), 1)
        occluders = np.isin(parse, [2, 13, 14])     # 머리카락·가방·액세서리
        for name, cid in GARMENT_CLASSES.items():
            if name == "bag":
                continue
            m = parse == cid
            if not m.any():
                continue
            ys, xs = np.nonzero(m)
            x1, x2, y1, y2 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
            # 가시 비율: 의류 bbox 내에서 가림 요소가 차지하지 않은 비율
            box_occ = occluders[y1:y2, x1:x2].sum()
            visible = float(m.sum() / max(m.sum() + box_occ, 1))
            out[name] = GarmentCrop(name, img[y1:y2, x1:x2].copy(), m[y1:y2, x1:x2].copy(),
                                    visible, float(m.sum() / total))
        return out

    # ---------------------------------------------------------------- 실행
    def run(self, frames: list[np.ndarray], sensor: SensorReading, *,
            depth: np.ndarray | None = None, mode: Mode = "daily",
            view: Literal["front", "side"] = "front",
            footwear: str | None = None) -> BodyResult:
        tr = Trace()
        with tr.stage("01_distance"):
            self.check_distance(sensor)
        with tr.stage("04_quality_gate"):
            k = self.cfg.capture.top_k_frames
            idx = select_frames(frames, self.cfg.quality, k)
            if not idx:
                raise RetakeRequired("잠시 움직이지 말고 서 주세요.", "quality_gate")
            frame = frames[idx[0]]
        with tr.stage("05_undistort"):
            frame = self.undistort(frame)
        with tr.stage("06_color_branch"):
            color_img = self.color_correct(frame, sensor, tr)
        with tr.stage("07_analysis_branch"):
            c = self.cfg.color
            analysis = C.clahe_l(frame, c.clahe_clip, c.clahe_tile)
        with tr.stage("08_target"):
            box = self.select_target(analysis, depth)
        with tr.stage("09_identify"):
            face_box, emb = self.face.detect_and_embed(analysis, box)
            uid, status, score = self.identify(emb)
            tr.flag("id_score", round(score, 3))
            if status != "auto":
                tr.flag("id_" + status, untrainable=True)   # 개인 학습 제외 [C6]
        with tr.stage("10_11_parse_separate"):
            raw = self.parser.parse(analysis, box)
            person = self.separate(color_img, raw, depth, box, tr)
            parse = self.clean_parse(raw, person)
            person = parse > 0
        kps = None
        measurement: dict = {}
        if mode == "measure":
            with tr.stage("12_pose"):
                kps = self.pose.estimate(analysis, box)
                self.check_pose(kps, view)
            with tr.stage("13_occlusion"):
                measurement.update(self.occlusion(kps, parse, person, depth, tr))
        with tr.stage("14_footwear"):
            measurement["footwear_offset_cm"] = self.footwear_offset(footwear, parse, mode, tr)
        with tr.stage("15_anonymize"):
            safe = self.anonymize(color_img, face_box)
            safe[~person] = 255                         # 배경도 서버로 보내지 않음
        with tr.stage("16_normalize"):
            vton = self.crop_resize(safe, person, self.cfg.body.vton_size)
            pose_in = self.crop_resize(self.anonymize(analysis, face_box), person,
                                       self.cfg.body.pose_size)
            garments = self.garment_crops(color_img, parse, person)

        return BodyResult(uid, status, color_img, analysis, person, parse, garments, vton,
                          pose_in, face_box, kps, measurement, tr)


__all__ = ["BodyPipeline", "BodyResult", "DeviceCalibration", "SensorReading",
           "GarmentCrop", "guided_filter", "PARSE_CLASSES"]
