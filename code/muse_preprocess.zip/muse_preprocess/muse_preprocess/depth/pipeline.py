"""깊이(Depth) 전처리 파이프라인 (제안서 2장).

입력 깊이는 미터 단위 float32이며 0은 무효값이다.
RGB-D 정합(D2C)은 카메라 SDK의 하드웨어 정렬을 사용한다고 가정하고,
여기서는 타임스탬프 동기만 검증한다.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import warnings

import cv2
import numpy as np
from scipy import ndimage
from scipy.spatial import cKDTree

from ..common.types import RetakeRequired, Trace
from ..config import DepthConfig


@dataclass
class Intrinsics:
    fx: float
    fy: float
    cx: float
    cy: float


# ---------------------------------------------------------------- 0. 배경 모델

@dataclass
class BackgroundDepthModel:
    """설치 시 빈 장면으로 만드는 배경 모델 [A5][A7]. 낮·저녁 각각 등록 권장."""
    median: np.ndarray
    reflective: np.ndarray        # 반사·불안정 영역 상시 마스크 (bool)

    @classmethod
    def fit(cls, frames: list[np.ndarray], cfg: DepthConfig) -> "BackgroundDepthModel":
        stack = np.stack([np.where(f > 0, f, np.nan) for f in frames]).astype(np.float32)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            median = np.nanmedian(stack, axis=0)
            std = np.nanstd(stack, axis=0)
        invalid_rate = np.mean(np.isnan(stack), axis=0)
        reflective = (std > cfg.bg_std_reflective_m) | (invalid_rate > 0.5)
        # 반사 영역 경계 노이즈까지 덮도록 약간 팽창
        reflective = cv2.dilate(reflective.astype(np.uint8), np.ones((5, 5), np.uint8)) > 0
        return cls(median=np.nan_to_num(median, nan=0.0), reflective=reflective)

    def save(self, path: str) -> None:
        np.savez_compressed(path, median=self.median, reflective=self.reflective)

    @classmethod
    def load(cls, path: str) -> "BackgroundDepthModel":
        d = np.load(path)
        return cls(median=d["median"], reflective=d["reflective"])


# ---------------------------------------------------------------- 결과

@dataclass
class DepthResult:
    depth: np.ndarray                 # 필터링된 깊이 (무효 = NaN)
    foreground: np.ndarray            # 사용자 전경 마스크
    body_valid_ratio: float
    points: np.ndarray                # 바닥 기준 수직 좌표계 점군 (N, 3), 다운샘플 완료
    floor_plane: np.ndarray | None    # (a, b, c, d), 카메라 좌표계
    pitch_deg: float | None
    trace: Trace = field(default_factory=Trace)


# ---------------------------------------------------------------- 단계 함수

def mask_invalid(d: np.ndarray, cfg: DepthConfig) -> np.ndarray:
    out = d.astype(np.float32).copy()
    out[(out <= 0) | (out < cfg.valid_min_m) | (out > cfg.valid_max_m)] = np.nan
    return out


def remove_reflections(d: np.ndarray, bg: BackgroundDepthModel, cfg: DepthConfig) -> np.ndarray:
    out = d.copy()
    out[bg.reflective] = np.nan
    has_bg = bg.median > 0
    with np.errstate(invalid="ignore"):
        ghost = has_bg & (out > bg.median + cfg.behind_wall_m)   # 벽 뒤에 보이는 허상
    out[ghost] = np.nan
    return out


def foreground_mask(d: np.ndarray, bg: BackgroundDepthModel, user_range: tuple[float, float],
                    cfg: DepthConfig) -> np.ndarray:
    with np.errstate(invalid="ignore"):
        closer = np.where(bg.median > 0, bg.median - d > cfg.fg_diff_m, True)
        in_range = (d >= user_range[0]) & (d <= user_range[1])
    fg = (closer & in_range & ~np.isnan(d)).astype(np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(fg)
    if n <= 1:
        return np.zeros_like(fg, dtype=bool)
    largest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == largest


def spatial_filter(d: np.ndarray, cfg: DepthConfig) -> np.ndarray:
    """경계 보존 Bilateral. 무효 픽셀은 0으로 두면 깊이 σ 대비 차이가 커서 가중치가 사실상 0."""
    valid = ~np.isnan(d)
    filled = np.where(valid, d, 0.0).astype(np.float32)
    out = cv2.bilateralFilter(filled, cfg.bilateral_d, cfg.bilateral_sigma_depth_m,
                              cfg.bilateral_sigma_space)
    out[~valid] = np.nan
    return out


def temporal_filter(frames: list[np.ndarray], cfg: DepthConfig) -> np.ndarray:
    """최신 프레임 기준, 움직임이 임계값 이하인 픽셀만 최대 N프레임 평균 [C3]."""
    recent = frames[-cfg.temporal_max_frames:]
    ref = recent[-1]
    stack = np.stack(recent)
    with np.errstate(invalid="ignore"):
        ok = np.abs(stack - ref[None]) <= cfg.temporal_motion_m
    stack = np.where(ok, stack, np.nan)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        out = np.nanmean(stack, axis=0)
    return out.astype(np.float32)   # 최신 프레임이 무효인 픽셀은 NaN 유지


def fill_small_holes(d: np.ndarray, region: np.ndarray, cfg: DepthConfig) -> np.ndarray:
    """region 내부의 작은 구멍만 최근접 유효값으로 채운다. 큰 구멍은 SMPL-X 사전 형상에 맡김."""
    holes = np.isnan(d) & region
    if not holes.any():
        return d
    labels, n = ndimage.label(holes)
    sizes = ndimage.sum(holes, labels, range(1, n + 1))
    small = np.isin(labels, np.where(sizes < cfg.hole_max_px)[0] + 1)
    if not small.any():
        return d
    _, (iy, ix) = ndimage.distance_transform_edt(np.isnan(d), return_indices=True)
    out = d.copy()
    out[small] = d[iy[small], ix[small]]
    return out


def backproject(d: np.ndarray, mask: np.ndarray, K: Intrinsics) -> np.ndarray:
    ys, xs = np.nonzero(mask & ~np.isnan(d))
    z = d[ys, xs]
    return np.stack([(xs - K.cx) * z / K.fx, (ys - K.cy) * z / K.fy, z], axis=1)


def fit_floor_plane(points: np.ndarray, cfg: DepthConfig, seed: int = 0
                    ) -> np.ndarray | None:
    """RANSAC 평면 피팅. 카메라 y축(아래)과 거의 평행한 법선을 가진 평면만 바닥으로 인정."""
    if len(points) < 50:
        return None
    rng = np.random.default_rng(seed)
    best, best_inliers = None, 0
    for _ in range(cfg.ransac_iters):
        p = points[rng.choice(len(points), 3, replace=False)]
        n = np.cross(p[1] - p[0], p[2] - p[0])
        norm = np.linalg.norm(n)
        if norm < 1e-9:
            continue
        n /= norm
        if abs(n[1]) < np.cos(np.radians(35)):     # 바닥 후보가 아님
            continue
        dist = np.abs((points - p[0]) @ n)
        inliers = int((dist < cfg.ransac_thresh_m).sum())
        if inliers > best_inliers:
            best_inliers, best = inliers, np.append(n, -n @ p[0])
    if best is None or best_inliers < 0.2 * len(points):
        return None
    # 인라이어로 최소제곱 재추정
    inl = points[np.abs(points @ best[:3] + best[3]) < cfg.ransac_thresh_m]
    c = inl.mean(axis=0)
    _, _, vt = np.linalg.svd(inl - c)
    n = vt[-1]
    if n[1] > 0:          # 법선이 위(카메라 -y)를 향하도록
        n = -n
    return np.append(n, -n @ c)


def level_rotation(plane: np.ndarray) -> tuple[np.ndarray, float]:
    """바닥 법선을 세계 '위'(카메라 -y)에 맞추는 회전행렬과 카메라 피치(도)."""
    n = plane[:3] / np.linalg.norm(plane[:3])
    up = np.array([0.0, -1.0, 0.0])
    v = np.cross(n, up)
    s, c = np.linalg.norm(v), float(n @ up)
    if s < 1e-9:
        return np.eye(3), 0.0
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    R = np.eye(3) + vx + vx @ vx * ((1 - c) / s**2)
    pitch = float(np.degrees(np.arctan2(n[2], -n[1])))
    return R, pitch


def voxel_downsample(points: np.ndarray, voxel: float) -> np.ndarray:
    if len(points) == 0:
        return points
    keys = np.floor(points / voxel).astype(np.int64)
    _, inv = np.unique(keys, axis=0, return_inverse=True)
    inv = inv.ravel()
    sums = np.zeros((inv.max() + 1, 3))
    np.add.at(sums, inv, points)
    counts = np.bincount(inv)[:, None]
    return sums / counts


def statistical_outlier_removal(points: np.ndarray, k: int, std_ratio: float) -> np.ndarray:
    if len(points) <= k:
        return points
    dist, _ = cKDTree(points).query(points, k=k + 1)
    mean_d = dist[:, 1:].mean(axis=1)
    keep = mean_d <= mean_d.mean() + std_ratio * mean_d.std()
    return points[keep]


# ---------------------------------------------------------------- 파이프라인

class DepthPipeline:
    def __init__(self, cfg: DepthConfig, bg: BackgroundDepthModel, K: Intrinsics,
                 user_range: tuple[float, float] = (1.9, 2.6),
                 reference_pitch_deg: float | None = None):
        self.cfg, self.bg, self.K, self.user_range = cfg, bg, K, user_range
        self.reference_pitch_deg = reference_pitch_deg   # 설치 시 측정값 [A3]

    def run(self, frames: list[np.ndarray], *, body_mask: np.ndarray | None = None,
            rgb_ts_ms: float | None = None, depth_ts_ms: float | None = None,
            build_points: bool = True) -> DepthResult:
        cfg, tr = self.cfg, Trace()

        with tr.stage("sync_check"):
            if rgb_ts_ms is not None and depth_ts_ms is not None:
                if abs(rgb_ts_ms - depth_ts_ms) > cfg.sync_max_ms:
                    raise RetakeRequired("잠시 후 다시 시도해 주세요.", "rgbd_desync")

        with tr.stage("invalid_reflection"):
            cleaned = [remove_reflections(mask_invalid(f, cfg), self.bg, cfg) for f in frames]
        # 시간 필터를 먼저 적용해 공간 필터는 1회만 수행 (프레임별 적용 대비 약 5배 빠름)
        with tr.stage("temporal"):
            d = temporal_filter(cleaned, cfg)
        with tr.stage("spatial"):
            d = spatial_filter(d, cfg)
        with tr.stage("foreground"):
            fg = foreground_mask(d, self.bg, self.user_range, cfg)
        region = body_mask if body_mask is not None else fg
        with tr.stage("hole_fill"):
            hull = cv2.morphologyEx(region.astype(np.uint8), cv2.MORPH_CLOSE,
                                    np.ones((15, 15), np.uint8)) > 0
            d = fill_small_holes(d, hull, cfg)

        valid_ratio = float(np.mean(~np.isnan(d[region]))) if region.any() else 0.0
        if 1 - valid_ratio > cfg.body_invalid_ratio_max:
            tr.flag("low_depth_confidence", round(1 - valid_ratio, 3), untrainable=True)

        plane, pitch, pts = None, None, np.empty((0, 3))
        if build_points:
            with tr.stage("floor_plane"):
                lower = np.zeros_like(fg)
                lower[int(d.shape[0] * 0.6):] = True
                floor_pts = backproject(d, lower & ~fg & ~self.bg.reflective, self.K)
                plane = fit_floor_plane(floor_pts[:: max(1, len(floor_pts) // 5000)], cfg)
            R = np.eye(3)
            if plane is not None:
                R, pitch = level_rotation(plane)
                if (self.reference_pitch_deg is not None
                        and abs(pitch - self.reference_pitch_deg) > cfg.pitch_change_warn_deg):
                    tr.flag("mount_moved", round(pitch - self.reference_pitch_deg, 2))
            else:
                tr.flag("floor_not_found")
            with tr.stage("pointcloud"):
                pts = backproject(d, region, self.K) @ R.T
                pts = voxel_downsample(pts, cfg.voxel_m)
                pts = statistical_outlier_removal(pts, cfg.sor_neighbors, cfg.sor_std_ratio)

        return DepthResult(d, fg, valid_ratio, pts, plane, pitch, tr)
