"""MUSE 전처리 파라미터.

모든 수치는 가구 001 현장 조사 기반 초기값(가정)이다.
J 샘플 데이터(빈 배경, 컬러체커, 깊이 프레임)를 확보한 뒤 YAML로 덮어써서 재조정한다.
주석의 [A5], [B3] 등은 현장 조사 가이드 항목 번호다.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict, fields, is_dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass
class CaptureConfig:
    min_distance_m: float = 1.9           # [A2] 유효 촬영 거리 하한
    max_distance_m: float = 2.6           # [A2] 유효 촬영 거리 상한
    target_lux_min: float = 400.0         # [B3] LED 목표 조도
    target_lux_max: float = 600.0
    burst_frames_daily: int = 15          # [C3] 정지 1초 미만 대응 (30fps × 0.5초)
    burst_frames_measure: int = 60
    top_k_frames: int = 3


@dataclass
class QualityConfig:
    blur_downsample_width: int = 1280     # 720p 기준으로 Laplacian 분산 계산
    blur_var_min: float = 100.0           # [C3][A10] 블러 임계값
    clip_ratio_max: float = 0.02          # 노출 클리핑 픽셀 비율 상한
    motion_max: float = 4.0               # 프레임 간 평균 절대 차이(0~255) 상한


@dataclass
class ColorConfig:
    ambient_ratio_max: float = 0.30       # [B1][B2] 주변광 비율 초과 시 색 신뢰도 낮음
    clahe_clip: float = 2.0               # [D4][A6] 분석 브랜치 전용
    clahe_tile: int = 8
    achromatic_chroma_max: float = 8.0    # Lab C* 미만은 무채색
    specular_v_min: float = 0.92          # [D6] 정반사 판정
    specular_s_max: float = 0.12
    specular_rel_l: float = 20.0          # 의류 L 중앙값보다 20 이상 밝아야 하이라이트 (흰 옷 보호)
    glossy_ratio_tag: float = 0.08        # 하이라이트 비율이 이 이상이면 '광택 소재' 태깅
    edge_erode_px: int = 5                # 색 추출 시 경계 번짐 제외
    sheer_alpha_min: float = 0.6          # [D6] 알파 미만은 색 추출 제외
    shadow_rel_dark: float = 0.35         # [D7] 의류 L 중앙값 대비 35% 이상 어두우면 그림자
    shadow_weight: float = 0.3
    kmeans_k_range: tuple[int, int] = (3, 5)
    flatlay_ccm_max_delta_e: float = 6.0  # 매트 패치 보정 후 평균 ΔE 상한


@dataclass
class BodyConfig:
    center_ratio: float = 0.40            # [A7][C6] 화면 중앙 40% 이내 인물만 타깃
    face_match_auto: float = 0.50         # [C6] 얼굴 임베딩 자동 식별
    face_match_confirm: float = 0.35      # 이 이상이면 확인 요청, 미만은 게스트
    depth_gate_m: float = 0.40            # [A5] 몸통 깊이 ±0.4m
    guided_radius: int = 8
    guided_eps: float = 1e-3
    min_part_area_ratio: float = 0.005    # 파싱 클래스 최소 면적
    arm_angle_range: tuple[float, float] = (20.0, 45.0)  # [C2] A-pose
    arm_angle_tol: float = 15.0
    side_rot_range: tuple[float, float] = (80.0, 100.0)
    joint_conf_min: float = 0.5
    max_low_conf_joints: int = 1          # 2개 이상이면 재촬영
    bag_area_max: float = 0.03            # [C4]
    face_bbox_expand: float = 0.20
    crop_margin: float = 0.10
    vton_size: tuple[int, int] = (768, 1024)   # (W, H)
    pose_size: tuple[int, int] = (192, 256)
    # [C5] 신발 높이 오프셋 cm (가정, 실측 보정 필요)
    footwear_offset_cm: dict[str, float] = field(default_factory=lambda: {
        "barefoot": 0.0, "socks": 0.0, "slippers": 1.5, "sneakers": 3.0,
        "dress_shoes": 4.0, "boots": 4.0,
    })


@dataclass
class DepthConfig:
    valid_min_m: float = 0.5
    valid_max_m: float = 3.5
    bg_std_reflective_m: float = 0.03     # [A7] 배경 표준편차 > 3cm → 반사 영역
    behind_wall_m: float = 0.30           # 벽보다 0.3m 이상 먼 값 = 허상
    fg_diff_m: float = 0.08               # 배경 대비 8cm 이상 가까우면 전경
    bilateral_sigma_space: float = 5.0
    bilateral_d: int = 9                  # 커널 지름 (지연 예산 고려)
    bilateral_sigma_depth_m: float = 0.02
    temporal_max_frames: int = 5          # [C3]
    temporal_motion_m: float = 0.02
    hole_max_px: int = 15
    body_invalid_ratio_max: float = 0.10  # [D4][D6] 검정·광택 옷의 깊이 결손
    ransac_thresh_m: float = 0.01         # [A4] 바닥 평면
    ransac_iters: int = 200
    pitch_change_warn_deg: float = 2.0    # [A3]
    voxel_m: float = 0.005
    sor_neighbors: int = 20
    sor_std_ratio: float = 2.0
    sync_max_ms: float = 10.0


@dataclass
class WardrobeConfig:
    marker_blur_var_min: float = 1000.0   # 매트 마커 영역 Laplacian 분산 (의류 내용과 무관한 기준)
    marker_reproj_max_px: float = 2.0
    mm_per_px: float = 1.0                # 정면 변환 결과 해상도
    seg_conf_min: float = 0.85
    min_long_side: int = 1024             # [D5] 패턴 보존
    detail_crop: int = 512
    ocr_conf_min: float = 0.85            # [D9]
    dup_sim_high: float = 0.95            # [D8] 중복 의심
    dup_sim_low: float = 0.90             # 디테일 재비교 구간
    dup_delta_e_max: float = 5.0
    worn_sim_auto: float = 0.80           # 착용 자동 기록
    worn_sim_confirm: float = 0.65
    worn_delta_e_max: float = 12.0
    worn_visible_min: float = 0.60        # [C4] 가시 비율
    worn_area_min_ratio: float = 0.30


@dataclass
class CatalogConfig:
    phash_dup_dist: int = 6
    type_conf_min: float = 0.80
    upscale_below: int = 768              # [E2]
    reject_below: int = 384
    target_size: tuple[int, int] = (768, 1024)
    color_delta_e_flag: float = 15.0      # [E3]
    color_review_ratio_flag: float = 0.05
    autotag_conf_min: float = 0.85        # [E5]
    estimated_size_conf: float = 0.5      # [E4] S/M/L만 있는 상품


@dataclass
class ContextConfig:
    forecast_stale_h: float = 6.0
    pre_event_buffer_h: float = 1.0
    exposure_weight: dict[str, float] = field(default_factory=lambda: {
        "car": 0.3, "transit": 1.0, "walk": 1.0, "remote": 0.1,
    })                                    # [F3] (가정)
    layering_temp_gap_c: float = 10.0     # [F4]
    title_sim_merge: float = 0.8          # [F1]
    overlap_merge: float = 0.5
    label_conf_min: float = 0.7
    default_formality: int = 3


@dataclass
class FeedbackConfig:
    queue_retention_days: int = 7         # [H2]
    tap_merge_s: float = 1.0
    clock_skew_max_s: float = 2.0
    attribution_conf_min: float = 0.5     # [C6]
    session_timeout_s: float = 300.0      # [I3]
    half_life_days: float = 60.0
    propensity_floor: float = 0.05
    fatigue_drop_ratio: float = 0.5       # [G2]
    implicit_boost: float = 1.5
    event_weights: dict[str, float] = field(default_factory=lambda: {
        "purchase": 1.0, "worn": 0.8, "like": 0.5, "impression": 0.0,
        "dislike": -0.7, "uncomfortable": -1.0,
    })
    # [G3] 추천 미착용 사유별 라벨
    skip_reason_weights: dict[str, tuple[str, float]] = field(default_factory=lambda: {
        "uncomfortable": ("item", -1.0),
        "mood": ("outfit", -0.2),
        "laundry": ("none", 0.0),
        "schedule_change": ("none", 0.0),
    })


@dataclass
class MuseConfig:
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    quality: QualityConfig = field(default_factory=QualityConfig)
    color: ColorConfig = field(default_factory=ColorConfig)
    body: BodyConfig = field(default_factory=BodyConfig)
    depth: DepthConfig = field(default_factory=DepthConfig)
    wardrobe: WardrobeConfig = field(default_factory=WardrobeConfig)
    catalog: CatalogConfig = field(default_factory=CatalogConfig)
    context: ContextConfig = field(default_factory=ContextConfig)
    feedback: FeedbackConfig = field(default_factory=FeedbackConfig)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "MuseConfig":
        """YAML의 일부 키만 덮어쓴다. 없는 키는 기본값 유지."""
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        cfg = cls()
        _merge(cfg, data)
        return cfg

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _merge(obj: Any, data: dict[str, Any]) -> None:
    names = {f.name for f in fields(obj)}
    for key, value in data.items():
        if key not in names:
            raise KeyError(f"알 수 없는 설정 키: {type(obj).__name__}.{key}")
        current = getattr(obj, key)
        if is_dataclass(current) and isinstance(value, dict):
            _merge(current, value)
        elif isinstance(current, tuple):
            setattr(obj, key, tuple(value))
        else:
            setattr(obj, key, value)
