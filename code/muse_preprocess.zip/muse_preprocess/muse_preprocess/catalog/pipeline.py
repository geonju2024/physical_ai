"""쇼핑몰 상품 이미지·메타데이터 전처리 (제안서 4장). Cloud 일 1회 배치."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

import cv2
import numpy as np
from skimage.color import deltaE_ciede2000

from ..common import color as C
from ..common.types import Trace
from ..config import CatalogConfig, ColorConfig
from ..models.interfaces import ImageEmbedder, ImageTypeClassifier

TYPE_PRIORITY = {"cutout": 0, "model": 1, "lifestyle": 2, "detail": 9}

# 색상명 → 대표 Lab (가정, 사내 색상 사전으로 교체)
COLOR_NAME_LAB = {
    "black": (10, 0, 0), "블랙": (10, 0, 0), "white": (96, 0, 2), "화이트": (96, 0, 2),
    "ivory": (93, 0, 10), "아이보리": (93, 0, 10), "gray": (55, 0, 0), "그레이": (55, 0, 0),
    "navy": (20, 5, -30), "네이비": (20, 5, -30), "beige": (80, 3, 15), "베이지": (80, 3, 15),
    "camel": (60, 12, 32), "카멜": (60, 12, 32), "red": (45, 65, 45), "레드": (45, 65, 45),
    "blue": (45, 10, -55), "블루": (45, 10, -55), "green": (50, -40, 30), "그린": (50, -40, 30),
    "khaki": (52, -5, 25), "카키": (52, -5, 25), "brown": (35, 15, 25), "브라운": (35, 15, 25),
}

# 사이즈 항목 표준명. '단면'은 ×2 해서 둘레로 환산 [E4]
SIZE_FIELD_ALIASES = {
    "총장": "length", "기장": "length", "length": "length",
    "어깨너비": "shoulder", "어깨": "shoulder", "shoulder": "shoulder",
    "가슴단면": "chest_half", "가슴둘레": "chest", "chest": "chest",
    "허리단면": "waist_half", "허리둘레": "waist", "waist": "waist",
    "엉덩이단면": "hip_half", "힙단면": "hip_half", "엉덩이둘레": "hip", "hip": "hip",
    "소매길이": "sleeve", "소매": "sleeve", "sleeve": "sleeve",
    "밑단단면": "hem_half", "허벅지단면": "thigh_half", "인심": "inseam",
}
UNIT_TO_CM = {"cm": 1.0, "mm": 0.1, "inch": 2.54, "in": 2.54, '"': 2.54}


@dataclass
class ProductImage:
    url: str
    image: np.ndarray


@dataclass
class Product:
    product_id: str
    images: list[ProductImage]
    meta: dict                                  # color, material, fit, category ...
    size_table: dict[str, dict[str, str]] | None = None   # {"M": {"가슴단면": "52cm"}}
    size_labels: list[str] = field(default_factory=list)  # S/M/L만 있는 경우
    brand: str = ""
    category: str = ""
    review_color_mismatch_ratio: float = 0.0    # 리뷰 텍스트 마이닝 결과 [E3]


@dataclass
class CatalogResult:
    product_id: str
    vton_ready: bool
    vton_image: np.ndarray | None
    vton_mask: np.ndarray | None
    source_type: str | None
    detail_refs: list[str]
    color_confidence: str                       # "high" | "low"
    sizes_cm: dict[str, dict[str, float]]
    size_confidence: float
    meta: dict
    meta_source: dict[str, str]
    embedding: np.ndarray | None
    review_queue: list[str]
    trace: Trace


# ---------------------------------------------------------------- 유틸

def phash(img: np.ndarray) -> int:
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (32, 32),
                   interpolation=cv2.INTER_AREA).astype(np.float32)
    d = cv2.dct(g)[:8, :8].ravel()
    bits = d > np.median(d[1:])
    return int("".join("1" if b else "0" for b in bits), 2)


def hamming(a: int, b: int) -> int:
    return bin(a ^ b).count("1")


def dedupe_images(images: list[ProductImage], max_dist: int) -> list[ProductImage]:
    kept, hashes = [], []
    for im in images:
        if im.image is None or im.image.size == 0:
            continue                             # 깨진 이미지
        h = phash(im.image)
        if any(hamming(h, k) <= max_dist for k in hashes):
            continue
        kept.append(im)
        hashes.append(h)
    return kept


def white_bg_alpha(img: np.ndarray, thresh: int = 242) -> np.ndarray:
    """누끼컷 흰 배경 제거. 테두리에 연결된 흰 영역만 배경으로 처리(흰 옷 내부 보존)."""
    white = (img.min(axis=2) >= thresh).astype(np.uint8)
    n, labels = cv2.connectedComponents(white)
    border = set(np.unique(np.concatenate([labels[0], labels[-1], labels[:, 0], labels[:, -1]])))
    bg = np.isin(labels, [l for l in border if l != 0]) & (white > 0)
    alpha = (~bg).astype(np.float32)
    return cv2.GaussianBlur(alpha, (3, 3), 0)


def letterbox(img: np.ndarray, mask: np.ndarray, size: tuple[int, int]
              ) -> tuple[np.ndarray, np.ndarray]:
    tw, th = size
    h, w = img.shape[:2]
    s = min(tw / w, th / h)
    nw, nh = max(1, int(w * s)), max(1, int(h * s))
    interp = cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC
    r, rm = cv2.resize(img, (nw, nh), interpolation=interp), cv2.resize(mask, (nw, nh))
    canvas = np.full((th, tw, 3), 255, np.uint8)
    cmask = np.zeros((th, tw), np.float32)
    oy, ox = (th - nh) // 2, (tw - nw) // 2
    canvas[oy:oy + nh, ox:ox + nw] = r
    cmask[oy:oy + nh, ox:ox + nw] = rm
    return canvas, cmask


def parse_measure(value: str) -> float | None:
    m = re.search(r"([\d.]+)\s*(cm|mm|inch|in|\")?", str(value).strip().lower())
    if not m:
        return None
    return float(m.group(1)) * UNIT_TO_CM.get(m.group(2) or "cm", 1.0)


def normalize_size_table(table: dict[str, dict[str, str]]) -> dict[str, dict[str, float]]:
    out: dict[str, dict[str, float]] = {}
    for size, row in table.items():
        norm: dict[str, float] = {}
        for k, v in row.items():
            key = SIZE_FIELD_ALIASES.get(k.replace(" ", "").lower(),
                                         SIZE_FIELD_ALIASES.get(k.replace(" ", "")))
            val = parse_measure(v)
            if key is None or val is None:
                continue
            if key.endswith("_half"):
                norm[key.removesuffix("_half")] = round(val * 2, 1)   # 단면 → 둘레
            else:
                norm[key] = round(val, 1)
        out[size.strip().upper()] = norm
    return out


# ---------------------------------------------------------------- 파이프라인

class CatalogPipeline:
    def __init__(self, cfg: CatalogConfig, ccfg: ColorConfig, classifier: ImageTypeClassifier,
                 embedder: ImageEmbedder,
                 garment_extractor: Callable[[np.ndarray], tuple[np.ndarray, float]] | None = None,
                 upscaler: Callable[[np.ndarray], np.ndarray] | None = None,
                 autotagger: Callable[[np.ndarray], dict[str, tuple[str, float]]] | None = None,
                 standard_sizes: dict[tuple[str, str], dict[str, dict[str, float]]] | None = None):
        self.cfg, self.ccfg = cfg, ccfg
        self.classifier, self.embedder = classifier, embedder
        self.garment_extractor = garment_extractor   # 모델컷 → 의류 영역 (Human Parsing)
        self.upscaler = upscaler                     # Real-ESRGAN 계열 ×2
        self.autotagger = autotagger
        self.standard_sizes = standard_sizes or {}   # (brand|"*", category) → S/M/L 표준 치수

    def run(self, p: Product) -> CatalogResult:
        cfg, tr, review = self.cfg, Trace(), []
        with tr.stage("01_dedupe"):
            images = dedupe_images(p.images, cfg.phash_dup_dist)
        with tr.stage("02_classify"):
            typed = []
            for im in images:
                t, conf = self.classifier.classify(im.image)
                if conf < cfg.type_conf_min:
                    review.append(f"type_review:{im.url}")
                typed.append((t, conf, im))
        with tr.stage("03_select"):
            details = [im.url for t, _, im in typed if t == "detail"]
            cands = sorted([x for x in typed if x[0] != "detail"],
                           key=lambda x: (TYPE_PRIORITY.get(x[0], 9), -x[1]))
        vton_img = vton_mask = None
        src_type = None
        with tr.stage("04_05_extract_resize"):
            for t, _, im in cands:
                alpha = self._extract(t, im.image)
                if alpha is None:
                    continue
                img = im.image
                long_side = max(img.shape[:2])
                if long_side < cfg.reject_below:
                    tr.flag("too_small", long_side)
                    continue
                if long_side < cfg.upscale_below:
                    if self.upscaler is not None:
                        img = self.upscaler(img)
                    else:
                        img = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
                    alpha = cv2.resize(alpha, (img.shape[1], img.shape[0]))
                    tr.flag("upscaled")
                vton_img, vton_mask = letterbox(img, alpha, cfg.target_size)
                src_type = t
                break
        with tr.stage("06_color_confidence"):
            color_conf = self._color_confidence(p, vton_img, vton_mask, tr)
        with tr.stage("07_sizes"):
            sizes, size_conf = self._sizes(p, tr)
        with tr.stage("08_meta_fill"):
            meta, meta_src = self._fill_meta(p, vton_img)
        with tr.stage("09_embed"):
            emb = self.embedder.embed(vton_img, vton_mask) if vton_img is not None else None

        return CatalogResult(p.product_id, vton_img is not None, vton_img, vton_mask, src_type,
                             details, color_conf, sizes, size_conf, meta, meta_src, emb,
                             review, tr)

    def _extract(self, t: str, img: np.ndarray) -> np.ndarray | None:
        if t == "cutout":
            return white_bg_alpha(img)
        if t == "model" and self.garment_extractor is not None:
            alpha, conf = self.garment_extractor(img)
            return alpha if conf >= 0.5 else None
        return None                               # 연출컷은 VTON 입력으로 쓰지 않음

    def _color_confidence(self, p: Product, img, mask, tr: Trace) -> str:
        """[E3] 상품 이미지 색은 판매 정보이므로 보정하지 않고 신뢰도만 산출."""
        low = p.review_color_mismatch_ratio > self.cfg.color_review_ratio_flag
        name = str(p.meta.get("color", "")).strip().lower()
        if img is not None and name in COLOR_NAME_LAB:
            m = mask > 0.5
            colors = C.dominant_colors(C.bgr8_to_lab(img)[m], None, self.ccfg.kmeans_k_range)
            if colors:
                de = float(deltaE_ciede2000(np.array(colors[0]["lab"]).reshape(1, 1, 3),
                                            np.array(COLOR_NAME_LAB[name], float).reshape(1, 1, 3))[0, 0])
                tr.flag("meta_color_delta_e", round(de, 2))
                low |= de > self.cfg.color_delta_e_flag
        return "low" if low else "high"

    def _sizes(self, p: Product, tr: Trace) -> tuple[dict, float]:
        if p.size_table:
            return normalize_size_table(p.size_table), 1.0
        if p.size_labels:
            std = (self.standard_sizes.get((p.brand, p.category))
                   or self.standard_sizes.get(("*", p.category)))
            if std:
                tr.flag("size_estimated")
                return ({s.upper(): std[s.upper()] for s in p.size_labels if s.upper() in std},
                        self.cfg.estimated_size_conf)
        tr.flag("size_missing")
        return {}, 0.0

    def _fill_meta(self, p: Product, img) -> tuple[dict, dict]:
        meta = dict(p.meta)
        src = {k: "seller" for k, v in meta.items() if v not in (None, "")}
        if self.autotagger is None or img is None:
            return meta, src
        for k, (v, conf) in self.autotagger(img).items():
            if meta.get(k) in (None, "") and conf >= self.cfg.autotag_conf_min:
                meta[k], src[k] = v, "ai"
        return meta, src
