"""옷장 의류 이미지 전처리 (제안서 3장).

도메인 A: MUSE 촬영 매트 위 펼침 촬영 (QR 웹 업로드 → Cloud)  [D2][D1]
도메인 B: 미러 앞 착용 상태 인식 (Edge, BodyPipeline 결과 재사용)  [D2][C4]
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Literal

import cv2
import numpy as np
from skimage.color import deltaE_ciede2000, rgb2lab

from ..common import color as C
from ..common.quality import blur_score
from ..common.types import RetakeRequired, Trace
from ..config import ColorConfig, WardrobeConfig
from ..models.interfaces import GarmentSegmenter, ImageEmbedder

# ---------------------------------------------------------------- 촬영 매트 사양

ARUCO_DICT = cv2.aruco.DICT_4X4_50


@dataclass
class Patch:
    center_mm: tuple[float, float]
    size_mm: float
    ref_rgb: tuple[float, float, float]     # sRGB 0~1 (D65 기준 인쇄 측정값)


@dataclass
class MatSpec:
    """MUSE 촬영 매트 (가정). 4 모서리 ArUco + 상단 컬러 패치 띠.

    배경은 유채색(크로마키 계열 그린)으로 한다. 가구 001 옷장이 검정·흰색·회색 위주이고
    [D4] 광택 하이라이트[D6]가 흰색에 가깝기 때문에, 무채색 배경이면 경계가 사라진다.
    """
    width_mm: float = 1000.0
    height_mm: float = 1200.0
    marker_mm: float = 80.0
    margin_mm: float = 20.0
    background_rgb: tuple[float, float, float] = (0.30, 0.62, 0.42)
    patches: list[Patch] = field(default_factory=lambda: [
        Patch((200 + 100 * i, 60), 60, rgb) for i, rgb in enumerate([
            (0.95, 0.95, 0.95), (0.60, 0.60, 0.60), (0.25, 0.25, 0.25), (0.05, 0.05, 0.05),
            (0.75, 0.20, 0.20), (0.20, 0.60, 0.25), (0.20, 0.30, 0.75)])
    ])
    garment_top_mm: float = 130.0           # 이 아래가 의류 영역

    @property
    def background_bgr8(self) -> tuple[int, int, int]:
        return tuple(int(v * 255 + 0.5) for v in self.background_rgb[::-1])

    def marker_corners_mm(self) -> dict[int, np.ndarray]:
        m, s = self.margin_mm, self.marker_mm
        tl = {0: (m, m), 1: (self.width_mm - m - s, m),
              2: (self.width_mm - m - s, self.height_mm - m - s), 3: (m, self.height_mm - m - s)}
        return {i: np.array([[x, y], [x + s, y], [x + s, y + s], [x, y + s]], np.float32)
                for i, (x, y) in tl.items()}


# ---------------------------------------------------------------- 결과

@dataclass
class WardrobeItem:
    item_id: str
    embedding: np.ndarray
    colors: list[dict]
    measures_mm: dict[str, float]


@dataclass
class FlatlayResult:
    image: np.ndarray               # 원근·색 보정, 패턴 보존 리사이즈 완료
    mask: np.ndarray
    detail_crop: np.ndarray
    colors: list[dict]
    attributes: dict
    measures_mm: dict[str, float]
    embedding: np.ndarray
    duplicate: dict | None
    ccm_delta_e: float
    trace: Trace


# ---------------------------------------------------------------- 단계 함수

def detect_markers(img: np.ndarray) -> dict[int, np.ndarray]:
    det = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(ARUCO_DICT),
                                  cv2.aruco.DetectorParameters())
    corners, ids, _ = det.detectMarkers(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    if ids is None:
        return {}
    return {int(i): c.reshape(4, 2) for i, c in zip(ids.ravel(), corners)}


def rectify(img: np.ndarray, found: dict[int, np.ndarray], mat: MatSpec, mm_per_px: float
            ) -> tuple[np.ndarray, float]:
    """마커 16개 모서리로 호모그래피 추정 → 매트 정면 시점 (mm_per_px 해상도)."""
    ref = mat.marker_corners_mm()
    src = np.concatenate([found[i] for i in sorted(found) if i in ref])
    dst = np.concatenate([ref[i] for i in sorted(found) if i in ref]) / mm_per_px
    H, _ = cv2.findHomography(src, dst, cv2.RANSAC, 3.0)
    proj = cv2.perspectiveTransform(src.reshape(-1, 1, 2), H).reshape(-1, 2)
    err = float(np.sqrt(((proj - dst) ** 2).sum(axis=1)).mean())
    size = (int(mat.width_mm / mm_per_px), int(mat.height_mm / mm_per_px))
    return cv2.warpPerspective(img, H, size, flags=cv2.INTER_LINEAR,
                               borderValue=mat.background_bgr8), err


def sample_patches(rect: np.ndarray, mat: MatSpec, mm_per_px: float) -> np.ndarray:
    rgb = C.bgr8_to_rgb_float(rect)
    out = []
    for p in mat.patches:
        cx, cy = (np.array(p.center_mm) / mm_per_px).astype(int)
        r = int(p.size_mm / mm_per_px * 0.3)          # 가장자리 번짐 회피, 중앙 60%만
        out.append(np.median(rgb[cy - r:cy + r, cx - r:cx + r].reshape(-1, 3), axis=0))
    return np.array(out)


def specular_mask(img: np.ndarray, mask: np.ndarray, cfg: ColorConfig,
                  lab: np.ndarray | None = None) -> np.ndarray:
    """정반사 하이라이트 [D6]. 절대 밝기만 보면 흰 옷 전체가 하이라이트로 잡히므로
    의류 자체 밝기(L 중앙값)보다 충분히 밝은 픽셀만 인정한다."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    s, v = hsv[..., 1] / 255.0, hsv[..., 2] / 255.0
    L = (lab if lab is not None else C.bgr8_to_lab(img))[..., 0]
    med = float(np.median(L[mask])) if mask.any() else 100.0
    return (v > cfg.specular_v_min) & (s < cfg.specular_s_max) & (L > med + cfg.specular_rel_l) & mask


def shadow_weights(lab: np.ndarray, mask: np.ndarray, cfg: ColorConfig) -> np.ndarray:
    L = lab[..., 0]
    med = float(np.median(L[mask])) if mask.any() else 50.0
    w = np.where(L < med * (1 - cfg.shadow_rel_dark), cfg.shadow_weight, 1.0)
    return np.where(mask, w, 0.0)


def pattern_safe_resize(img: np.ndarray, min_long: int) -> np.ndarray:
    """긴 변을 min_long으로 축소. 축소 배율에 맞춘 안티앨리어싱으로 모아레 방지 [D5]."""
    h, w = img.shape[:2]
    scale = min_long / max(h, w)
    if scale >= 1:
        return img
    sigma = 0.5 / scale * 0.5
    blurred = cv2.GaussianBlur(img, (0, 0), sigma)
    return cv2.resize(blurred, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def detail_crop(img: np.ndarray, mask: np.ndarray, size: int) -> np.ndarray:
    """마스크 안에서 텍스처(Laplacian 에너지)가 가장 큰 size×size 창."""
    h, w = img.shape[:2]
    if h < size or w < size:
        return cv2.resize(img, (size, size), interpolation=cv2.INTER_LINEAR)
    energy = np.abs(cv2.Laplacian(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_32F))
    energy *= mask
    integ = cv2.integral(energy)
    best, by, bx = -1.0, 0, 0
    step = max(16, size // 8)
    for y in range(0, h - size + 1, step):
        for x in range(0, w - size + 1, step):
            s = integ[y + size, x + size] - integ[y, x + size] - integ[y + size, x] + integ[y, x]
            if s > best:
                best, by, bx = s, y, x
    return img[by:by + size, bx:bx + size].copy()


def measure(mask: np.ndarray, mm_per_px: float) -> dict[str, float]:
    """매트 스케일 기준 개략 실측 (구김 [D7] 때문에 ±2cm 허용)."""
    ys, xs = np.nonzero(mask)
    if len(ys) == 0:
        return {}
    y1, y2 = ys.min(), ys.max()
    def width_at(frac: float) -> float:
        row = mask[int(y1 + (y2 - y1) * frac)]
        nz = np.nonzero(row)[0]
        return float((nz.max() - nz.min()) * mm_per_px) if len(nz) else 0.0
    return {"length_mm": float((y2 - y1) * mm_per_px),
            "max_width_mm": float((xs.max() - xs.min()) * mm_per_px),
            "chest_mm": width_at(0.35), "hem_mm": width_at(0.95)}


def _cos(a: np.ndarray, b: np.ndarray) -> float:
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))


def _primary_delta_e(a: list[dict], b: list[dict]) -> float:
    if not a or not b:
        return 99.0
    return float(deltaE_ciede2000(np.array(a[0]["lab"]).reshape(1, 1, 3),
                                  np.array(b[0]["lab"]).reshape(1, 1, 3))[0, 0])


def check_duplicate(emb: np.ndarray, colors: list[dict], measures: dict[str, float],
                    wardrobe: list[WardrobeItem], cfg: WardrobeConfig,
                    detail_sim: Callable[[str], float] | None = None) -> dict | None:
    """[D3][D8] 임베딩 + 대표색 + 실측 결합 중복 판정.

    detail_sim(item_id): 0.90~0.95 구간에서 디테일 크롭끼리 재비교하는 콜백 (선택).
    """
    best = None
    for it in wardrobe:
        sim = _cos(emb, it.embedding)
        if best is None or sim > best[0]:
            best = (sim, it)
    if best is None or best[0] < cfg.dup_sim_low:
        return None
    sim, it = best
    de = _primary_delta_e(colors, it.colors)
    len_diff = abs(measures.get("length_mm", 0) - it.measures_mm.get("length_mm", 0))
    if sim >= cfg.dup_sim_high and de < cfg.dup_delta_e_max and len_diff < 30:
        return {"item_id": it.item_id, "similarity": round(sim, 4), "delta_e": round(de, 2),
                "action": "confirm_same"}
    if detail_sim is not None and detail_sim(it.item_id) >= cfg.dup_sim_high:
        return {"item_id": it.item_id, "similarity": round(sim, 4), "delta_e": round(de, 2),
                "action": "confirm_same_by_detail"}
    return {"item_id": it.item_id, "similarity": round(sim, 4), "delta_e": round(de, 2),
            "action": "similar_only"}


# ---------------------------------------------------------------- 도메인 A

class FlatlayPipeline:
    def __init__(self, wcfg: WardrobeConfig, ccfg: ColorConfig, segmenter: GarmentSegmenter,
                 embedder: ImageEmbedder, mat: MatSpec | None = None,
                 ocr: Callable[[np.ndarray], tuple[dict, float]] | None = None):
        self.w, self.c = wcfg, ccfg
        self.seg, self.emb, self.mat, self.ocr = segmenter, embedder, mat or MatSpec(), ocr

    def run(self, photo: np.ndarray, wardrobe: list[WardrobeItem], *,
            label_photo: np.ndarray | None = None) -> FlatlayResult:
        tr, w, c, mat = Trace(), self.w, self.c, self.mat
        with tr.stage("01_quality"):
            found = detect_markers(photo)
            if len(found) < 4:
                raise RetakeRequired("매트의 네 모서리가 모두 보이게 찍어 주세요.", "markers")
            # 전체 이미지 Laplacian 분산은 민무늬 옷·매트에서 낮게 나오므로,
            # 대비가 일정한 마커 영역에서만 선명도를 잰다.
            sharp = min(blur_score(photo[int(c[:, 1].min()):int(c[:, 1].max()),
                                         int(c[:, 0].min()):int(c[:, 0].max())])
                        for c in found.values())
            tr.flag("marker_sharpness", round(sharp, 1))
            if sharp < w.marker_blur_var_min:
                raise RetakeRequired("사진이 흔들렸어요. 다시 찍어 주세요.", "blur")
        with tr.stage("02_rectify"):
            rect, err = rectify(photo, found, mat, w.mm_per_px)
            if err > w.marker_reproj_max_px:
                raise RetakeRequired("매트를 평평하게 펴고 다시 찍어 주세요.", "reproj")
        with tr.stage("03_color"):
            measured = sample_patches(rect, mat, w.mm_per_px)
            ref = np.array([p.ref_rgb for p in mat.patches])
            ccm = C.estimate_ccm(measured, ref)
            rect = C.apply_ccm(rect, ccm)
            de = float(C.patch_delta_e(sample_patches(rect, mat, w.mm_per_px), ref).mean())
            if de > c.flatlay_ccm_max_delta_e:
                raise RetakeRequired("밝은 곳에서 다시 찍어 주세요.", "ccm_delta_e")
            tr.flag("ccm_delta_e", round(de, 2))
        with tr.stage("04_segment"):
            top = int(mat.garment_top_mm / w.mm_per_px)
            area = rect.copy()
            area[:top] = mat.background_bgr8
            margin = int((mat.margin_mm + mat.marker_mm) / w.mm_per_px)
            area[-margin:] = mat.background_bgr8
            alpha, conf = self.seg.segment(area)
            alpha[:top] = 0
            mask = alpha > 0.5
            if not mask.any():
                raise RetakeRequired("옷이 매트 안쪽에 오도록 놓아 주세요.", "no_garment")
            if conf < w.seg_conf_min:
                tr.flag("ask_boundary_confirm", round(conf, 3))
        attrs: dict = {}
        with tr.stage("05_06_07_color_weights"):
            lab = C.bgr8_to_lab(rect)
            spec = specular_mask(rect, mask, c, lab)
            spec_ratio = float(spec.sum() / mask.sum())
            tr.flag("specular_ratio", round(spec_ratio, 3))
            if spec_ratio >= c.glossy_ratio_tag:
                attrs["glossy"] = True
            sheer = mask & (alpha < c.sheer_alpha_min)
            attrs["sheerness"] = round(float(1 - alpha[mask].mean()), 3)
            inner = cv2.erode(mask.astype(np.uint8),
                              np.ones((2 * c.edge_erode_px + 1,) * 2, np.uint8)) > 0
            weights = shadow_weights(lab, mask, c)
            weights[spec | sheer | ~inner] = 0.0
        with tr.stage("08_dominant_colors"):
            colors = C.dominant_colors(lab[mask], weights[mask], c.kmeans_k_range)
            if colors:
                attrs["achromatic"] = colors[0]["chroma"] < c.achromatic_chroma_max
        with tr.stage("09_resize_detail"):
            ys, xs = np.nonzero(mask)
            pad = 10
            y1, y2 = max(0, ys.min() - pad), min(rect.shape[0], ys.max() + pad)
            x1, x2 = max(0, xs.min() - pad), min(rect.shape[1], xs.max() + pad)
            crop, cmask = rect[y1:y2, x1:x2], mask[y1:y2, x1:x2]
            detail = detail_crop(crop, cmask.astype(np.float32), w.detail_crop)
            small = pattern_safe_resize(crop, w.min_long_side)
            smask = cv2.resize(cmask.astype(np.uint8), (small.shape[1], small.shape[0]),
                               interpolation=cv2.INTER_NEAREST) > 0
        if label_photo is not None and self.ocr is not None:
            with tr.stage("10_ocr"):
                fields_, oconf = self.ocr(label_photo)
                if oconf >= w.ocr_conf_min:
                    attrs.update(fields_)
                else:
                    tr.flag("ocr_confirm", fields_)
        with tr.stage("11_measure"):
            measures = measure(mask, w.mm_per_px)
        with tr.stage("12_embed_dup"):
            emb = self.emb.embed(small, smask.astype(np.float32))
            dup = check_duplicate(emb, colors, measures, wardrobe, w)

        return FlatlayResult(small, smask, detail, colors, attrs, measures, emb, dup, de, tr)


# ---------------------------------------------------------------- 도메인 B

@dataclass
class WornMatch:
    garment_cls: str
    item_id: str | None
    similarity: float
    action: Literal["auto_worn", "confirm", "suggest_register", "skip_occluded"]


def match_worn(garments: dict, wardrobe: list[WardrobeItem], embedder: ImageEmbedder,
               wcfg: WardrobeConfig, ccfg: ColorConfig) -> list[WornMatch]:
    """BodyPipeline.garments → 본인 옷장 매칭 [G4: 옷 공유 없음 → 본인 옷장만 검색]."""
    out = []
    for name, g in garments.items():
        if g.visible_ratio < wcfg.worn_visible_min:
            out.append(WornMatch(name, None, 0.0, "skip_occluded"))
            continue
        emb = embedder.embed(g.image, g.mask.astype(np.float32))
        lab = C.bgr8_to_lab(g.image)[g.mask]
        colors = C.dominant_colors(lab, None, (2, 3)) if len(lab) else []
        best_item, best = None, -1.0
        for it in wardrobe:
            s = _cos(emb, it.embedding)
            if s > best:
                best_item, best = it, s
        if best_item is None:
            out.append(WornMatch(name, None, 0.0, "suggest_register"))
            continue
        de = _primary_delta_e(colors, best_item.colors)
        if best >= wcfg.worn_sim_auto and de < wcfg.worn_delta_e_max:
            action = "auto_worn"
        elif best >= wcfg.worn_sim_confirm:
            action = "confirm"
        else:
            action = "suggest_register"
        out.append(WornMatch(name, best_item.item_id if action != "suggest_register" else None,
                             round(best, 4), action))
    return out
