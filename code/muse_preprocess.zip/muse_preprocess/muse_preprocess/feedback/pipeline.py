"""행동·피드백 로그 전처리 (제안서 6장).

EdgeEventQueue : 미러 기기 측 SQLite 큐 (Wi-Fi 끊김 대비 [H2])
FeedbackPipeline: 서버 측 정제 → 학습용 라벨 행 생성
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
import uuid
from collections import defaultdict
from dataclasses import asdict, dataclass, field

from ..common.types import Trace
from ..config import FeedbackConfig

EVENT_TYPES = {"impression", "select", "like", "dislike", "uncomfortable", "worn",
               "purchase", "skip", "tryon"}
IMPLICIT = {"worn", "purchase", "select"}
EXPLICIT = {"like", "dislike", "uncomfortable"}


@dataclass
class FeedbackEvent:
    event_id: str
    device_id: str
    household_id: str
    type: str
    ts_device: float                 # 이벤트 발생 시각 (기기 시계, epoch 초)
    sent_at_device: float = 0.0      # 전송 시각 (기기 시계)
    ts_server: float = 0.0           # 서버 수신 시각
    user_id: str | None = None
    id_conf: float = 1.0             # BodyPipeline 식별 점수 [C6]
    outfit_id: str | None = None
    item_ids: list[str] = field(default_factory=list)
    position: str | None = None      # main | A | B | C
    propensity: float | None = None  # 해당 위치에 노출될 확률 (Bandit 로깅)
    reason: str | None = None        # skip 사유 [G3]
    session_id: str | None = None


# ---------------------------------------------------------------- Edge 큐

class EdgeEventQueue:
    def __init__(self, path: str, retention_days: int = 7):
        self.db = sqlite3.connect(path)
        self.retention_s = retention_days * 86400
        self.db.execute("CREATE TABLE IF NOT EXISTS q (id TEXT PRIMARY KEY, ts REAL, body TEXT)")
        self.db.commit()

    def enqueue(self, ev: FeedbackEvent) -> str:
        ev.event_id = ev.event_id or str(uuid.uuid4())    # 멱등 키
        self.db.execute("INSERT OR IGNORE INTO q VALUES (?,?,?)",
                        (ev.event_id, ev.ts_device, json.dumps(asdict(ev))))
        self.db.commit()
        return ev.event_id

    def pending(self, limit: int = 500) -> list[FeedbackEvent]:
        rows = self.db.execute("SELECT body FROM q ORDER BY ts LIMIT ?", (limit,)).fetchall()
        now = time.time()
        out = []
        for (b,) in rows:
            ev = FeedbackEvent(**json.loads(b))
            ev.sent_at_device = now
            out.append(ev)
        return out

    def ack(self, ids: list[str]) -> None:
        self.db.executemany("DELETE FROM q WHERE id=?", [(i,) for i in ids])
        self.db.commit()

    def purge_expired(self, now: float | None = None) -> int:
        cur = self.db.execute("DELETE FROM q WHERE ts < ?",
                              ((now or time.time()) - self.retention_s,))
        self.db.commit()
        return cur.rowcount

    @staticmethod
    def backoff_s(attempt: int) -> float:
        return min(1.0 * 2**attempt, 300.0)


# ---------------------------------------------------------------- 서버 정제

@dataclass
class LabelRow:
    user_id: str
    target: str            # item | outfit
    target_id: str
    label: float           # 가중치 × 감쇠 × IPS × 피로 보정
    ts: float
    source_event: str


@dataclass
class FeedbackOutput:
    rows: list[LabelRow]
    household_only: list[FeedbackEvent]
    events: list[FeedbackEvent]
    implicit_multiplier: dict[str, float]
    trace: Trace


class FeedbackPipeline:
    def __init__(self, cfg: FeedbackConfig):
        self.cfg = cfg

    # 2. 스키마 검증·중복 제거 ------------------------------------------
    def validate_dedupe(self, events: list[FeedbackEvent], tr: Trace) -> list[FeedbackEvent]:
        seen, out, bad = set(), [], 0
        for e in events:
            if not e.event_id or e.type not in EVENT_TYPES or not e.ts_device:
                bad += 1
                continue
            if e.event_id in seen:
                continue
            seen.add(e.event_id)
            out.append(e)
        out.sort(key=lambda e: e.ts_device)
        # 1초 이내 동일 버튼 연타 병합 [G2]
        merged: list[FeedbackEvent] = []
        last: dict[tuple, float] = {}
        for e in out:
            key = (e.device_id, e.type, e.outfit_id, tuple(e.item_ids))
            if e.type in EXPLICIT and key in last and e.ts_device - last[key] <= self.cfg.tap_merge_s:
                continue
            last[key] = e.ts_device
            merged.append(e)
        tr.flag("invalid_events", bad)
        tr.flag("dedup_removed", len(events) - bad - len(merged))
        return merged

    # 3. 시계 보정 -------------------------------------------------------
    def correct_clock(self, events: list[FeedbackEvent], tr: Trace) -> None:
        """기기 전송 시각과 서버 수신 시각 차이로 기기별 시계 오차 추정 (네트워크 지연 무시)."""
        offsets = defaultdict(list)
        for e in events:
            if e.sent_at_device and e.ts_server:
                offsets[e.device_id].append(e.ts_server - e.sent_at_device)
        for dev, offs in offsets.items():
            offs.sort()
            med = offs[len(offs) // 2]
            if abs(med) > self.cfg.clock_skew_max_s:
                tr.flag(f"clock_skew:{dev}", round(med, 2))
                for e in events:
                    if e.device_id == dev:
                        e.ts_device += med

    # 4. 사용자 귀속 -----------------------------------------------------
    def attribute(self, events: list[FeedbackEvent]
                  ) -> tuple[list[FeedbackEvent], list[FeedbackEvent]]:
        personal, household = [], []
        for e in events:
            (personal if e.user_id and e.id_conf >= self.cfg.attribution_conf_min
             else household).append(e)
        return personal, household

    # 5. 세션화 ----------------------------------------------------------
    def sessionize(self, events: list[FeedbackEvent]) -> None:
        last: dict[str, tuple[float, str]] = {}
        for e in sorted(events, key=lambda x: x.ts_device):
            prev = last.get(e.device_id)
            if prev is None or e.ts_device - prev[0] > self.cfg.session_timeout_s:
                sid = f"{e.device_id}:{int(e.ts_device)}"
            else:
                sid = prev[1]
            e.session_id = sid
            last[e.device_id] = (e.ts_device, sid)

    # 9. 피드백 피로 ------------------------------------------------------
    def implicit_multiplier(self, events: list[FeedbackEvent], now: float) -> dict[str, float]:
        """사용자별 세션당 명시 피드백 비율이 초기 4주 대비 절반 이하로 떨어지면 암묵 가중 ↑ [G2]."""
        out: dict[str, float] = {}
        by_user = defaultdict(list)
        for e in events:
            if e.user_id:
                by_user[e.user_id].append(e)
        week = 7 * 86400
        for uid, evs in by_user.items():
            first = min(e.ts_device for e in evs)
            def rate(lo: float, hi: float) -> float | None:
                sess = {e.session_id for e in evs if lo <= e.ts_device < hi}
                if not sess:
                    return None
                fb = {e.session_id for e in evs if lo <= e.ts_device < hi and e.type in EXPLICIT}
                return len(fb) / len(sess)
            base = rate(first, first + 4 * week)
            recent = rate(now - 4 * week, now + 1)
            out[uid] = (self.cfg.implicit_boost
                        if base and recent is not None and now - first > 8 * week
                        and recent <= base * self.cfg.fatigue_drop_ratio else 1.0)
        return out

    # 6·7·8. 라벨 생성 ---------------------------------------------------
    def to_rows(self, events: list[FeedbackEvent], mult: dict[str, float], now: float
                ) -> list[LabelRow]:
        cfg, rows = self.cfg, []
        lam = math.log(2) / (cfg.half_life_days * 86400)
        for e in events:
            decay = math.exp(-lam * max(now - e.ts_device, 0))
            ips = 1.0 / max(e.propensity, cfg.propensity_floor) if e.propensity else 1.0
            if e.type == "skip":
                target, w = cfg.skip_reason_weights.get(e.reason or "", ("none", 0.0))
                if target == "none" or w == 0:
                    continue                                  # 사유 없는 미착용은 라벨 미부여
            elif e.type in cfg.event_weights:
                w = cfg.event_weights[e.type]
                if w == 0:
                    continue
                target = "item" if e.type in ("uncomfortable", "purchase") else "outfit"
            else:
                continue
            if e.type in IMPLICIT:
                w *= mult.get(e.user_id or "", 1.0)
            targets = e.item_ids if target == "item" else [e.outfit_id] if e.outfit_id else []
            for t in targets:
                rows.append(LabelRow(e.user_id or "", target, t, round(w * decay * ips, 6),
                                     e.ts_device, e.event_id))
        return rows

    def run(self, events: list[FeedbackEvent], now: float | None = None) -> FeedbackOutput:
        tr = Trace()
        now = now or time.time()
        with tr.stage("02_validate_dedupe"):
            evs = self.validate_dedupe(events, tr)
        with tr.stage("03_clock"):
            self.correct_clock(evs, tr)
        with tr.stage("04_attribute"):
            personal, household = self.attribute(evs)
        with tr.stage("05_session"):
            self.sessionize(evs)
        with tr.stage("09_fatigue"):
            mult = self.implicit_multiplier(personal, now)
        with tr.stage("06_07_08_rows"):
            rows = self.to_rows(personal, mult, now)
        return FeedbackOutput(rows, household, evs, mult, tr)
