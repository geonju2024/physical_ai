"""딥러닝 모델 어댑터 인터페이스.

전처리 파이프라인은 이 Protocol에만 의존한다. 실제 배포 시
TensorRT(Edge)·Triton(Cloud) 기반 구현체를 같은 시그니처로 주입한다.
  - PersonDetector   : YOLO 계열 인물 검출
  - HumanParser      : SCHP 계열 Human Parsing
  - PoseEstimator    : RTMPose
  - FaceEmbedder     : ArcFace 계열 (Edge 전용, 얼굴 원본은 서버로 보내지 않음)
  - GarmentSegmenter : 의류 검출 + SAM 2
  - ImageEmbedder    : SigLIP 파인튜닝 모델 (옷장·쇼핑몰 공용 임베딩 공간)
  - ImageTypeClassifier : 쇼핑몰 이미지 4분류
  - TextLabeler      : LLM 기반 일정 해석 (약어 사전으로 해결 안 될 때만 호출)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np

# Human Parsing 클래스 (MUSE 내부 표준)
PARSE_CLASSES = {
    0: "background", 1: "hat", 2: "hair", 3: "face", 4: "upper", 5: "outer",
    6: "lower", 7: "dress", 8: "left_arm", 9: "right_arm", 10: "left_leg",
    11: "right_leg", 12: "shoes", 13: "bag", 14: "accessory", 15: "neck",
}
GARMENT_CLASSES = {"upper": 4, "outer": 5, "lower": 6, "dress": 7, "shoes": 12, "bag": 13}

# COCO 17 키포인트 순서
KP = {"nose": 0, "l_shoulder": 5, "r_shoulder": 6, "l_elbow": 7, "r_elbow": 8,
      "l_wrist": 9, "r_wrist": 10, "l_hip": 11, "r_hip": 12, "l_ankle": 15, "r_ankle": 16}


@dataclass
class PersonBox:
    x1: float
    y1: float
    x2: float
    y2: float
    score: float

    @property
    def center(self) -> tuple[float, float]:
        return (self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2


@dataclass
class FaceBox:
    x1: int
    y1: int
    x2: int
    y2: int


class PersonDetector(Protocol):
    def detect(self, img_bgr: np.ndarray) -> list[PersonBox]: ...


class HumanParser(Protocol):
    def parse(self, img_bgr: np.ndarray, box: PersonBox) -> np.ndarray:
        """입력과 같은 크기의 uint8 라벨맵(PARSE_CLASSES)."""
        ...


class PoseEstimator(Protocol):
    def estimate(self, img_bgr: np.ndarray, box: PersonBox) -> np.ndarray:
        """(17, 3) 배열: x, y, confidence."""
        ...


class FaceEmbedder(Protocol):
    def detect_and_embed(self, img_bgr: np.ndarray, box: PersonBox
                         ) -> tuple[FaceBox | None, np.ndarray | None]: ...


class GarmentSegmenter(Protocol):
    def segment(self, img_bgr: np.ndarray) -> tuple[np.ndarray, float]:
        """(float 마스크 0~1, 신뢰도). 마스크 값은 알파(투명도)로도 사용."""
        ...


class ImageEmbedder(Protocol):
    def embed(self, img_bgr: np.ndarray, mask: np.ndarray | None = None) -> np.ndarray:
        """L2 정규화된 1차원 벡터."""
        ...


class ImageTypeClassifier(Protocol):
    def classify(self, img_bgr: np.ndarray) -> tuple[str, float]:
        """('cutout'|'model'|'lifestyle'|'detail', 신뢰도)."""
        ...


class TextLabeler(Protocol):
    def label(self, text: str) -> dict:
        """{'formality': 1~5, 'activity': 1~3, 'outdoor': bool, 'confidence': float}."""
        ...
