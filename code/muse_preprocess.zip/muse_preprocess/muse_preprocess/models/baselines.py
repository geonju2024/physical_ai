"""개발·테스트용 기준 구현체.

실제 딥러닝 모델이 준비되기 전에 파이프라인 전체를 돌려보기 위한 것이다.
`Fixed*` 계열은 테스트 고정값 주입용이고, 나머지는 고전 CV 기반의 동작하는 베이스라인이다.
"""
from __future__ import annotations

import cv2
import numpy as np
from scipy import ndimage

from .interfaces import FaceBox, PersonBox


class FixedPersonDetector:
    def __init__(self, boxes: list[PersonBox]):
        self.boxes = boxes

    def detect(self, img_bgr):
        return list(self.boxes)


class FixedParser:
    def __init__(self, label_map: np.ndarray):
        self.label_map = label_map

    def parse(self, img_bgr, box):
        return self.label_map.copy()


class FixedPose:
    def __init__(self, keypoints: np.ndarray):
        self.keypoints = keypoints

    def estimate(self, img_bgr, box):
        return self.keypoints.copy()


class FixedFace:
    def __init__(self, face: FaceBox | None, embedding: np.ndarray | None):
        self.face, self.embedding = face, embedding

    def detect_and_embed(self, img_bgr, box):
        return self.face, self.embedding


class MatBackgroundSegmenter:
    """촬영 매트 배경색과의 Lab 거리로 의류를 분리하는 베이스라인 (SAM 2 대체용)."""

    def __init__(self, mat_bgr: tuple[int, int, int] = (107, 158, 77), thresh: float = 25.0):
        self.mat_lab = cv2.cvtColor(np.uint8([[mat_bgr]]), cv2.COLOR_BGR2LAB)[0, 0].astype(np.float32)
        self.thresh = thresh

    def segment(self, img_bgr):
        lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
        dist = np.linalg.norm(lab - self.mat_lab, axis=2)
        mask = (dist > self.thresh).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        n, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
        if n <= 1:
            return np.zeros(mask.shape, np.float32), 0.0
        largest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        mask = (labels == largest).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        # 펼친 옷 내부 구멍(광택 하이라이트 등)은 채운다. 시스루는 알파로 따로 처리
        mask = ndimage.binary_fill_holes(mask).astype(np.uint8)
        # 신뢰도: 경계 부근 거리값이 임계값에서 얼마나 떨어져 있는지
        edge = cv2.morphologyEx(mask, cv2.MORPH_GRADIENT, np.ones((3, 3), np.uint8)) > 0
        margin = np.abs(dist[edge] - self.thresh).mean() if edge.any() else 0.0
        conf = float(np.clip(margin / (2 * self.thresh), 0.0, 1.0) * 0.5 + 0.5)
        return mask.astype(np.float32), conf


class ColorHistEmbedder:
    """HSV 히스토그램 + 저해상 레이아웃 임베딩 (SigLIP 대체용 베이스라인)."""

    def embed(self, img_bgr, mask=None):
        m = None if mask is None else (mask > 0.5).astype(np.uint8)
        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1, 2], m, [12, 4, 4], [0, 180, 0, 256, 0, 256]).ravel()
        hist = hist / (hist.sum() + 1e-9)
        small = cv2.resize(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY), (8, 8),
                           interpolation=cv2.INTER_AREA).astype(np.float32).ravel() / 255.0
        v = np.concatenate([np.sqrt(hist), 0.3 * (small - small.mean())])
        return v / (np.linalg.norm(v) + 1e-9)


class BorderTypeClassifier:
    """테두리 흰색 비율로 누끼컷만 판별하는 베이스라인. 그 외는 'model' 저신뢰로 반환."""

    def classify(self, img_bgr):
        b = np.concatenate([img_bgr[:8].reshape(-1, 3), img_bgr[-8:].reshape(-1, 3),
                            img_bgr[:, :8].reshape(-1, 3), img_bgr[:, -8:].reshape(-1, 3)])
        white = float(np.mean(b.min(axis=1) >= 240))
        if white > 0.9:
            return "cutout", white
        return "model", 0.5


class NullLabeler:
    """LLM 미연결 시. 항상 저신뢰 응답을 돌려 기본값과 사용자 질문으로 넘어가게 한다."""

    def label(self, text):
        return {"formality": 3, "activity": 2, "outdoor": False, "confidence": 0.0}
