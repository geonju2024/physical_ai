"""테스트·데모용 합성 데이터. 가구 001의 어려운 조건을 재현한다.

- 베이지 벽 [A6] 앞 행거에 걸린 옷 [A5] (파서가 사용자 옷으로 오인식하도록 라벨 오염)
- TV 영역 깊이 반사 노이즈 [A7]
- 혼합 조명 색 틀어짐 [B1][B4]
"""
from __future__ import annotations

import cv2
import numpy as np

from .common.color import linear_to_srgb, srgb_to_linear
from .models.interfaces import FaceBox, PersonBox
from .wardrobe.pipeline import ARUCO_DICT, MatSpec

H, W = 960, 720              # 세로형 미러 카메라 (가정)
K = dict(fx=700.0, fy=700.0, cx=W / 2, cy=H / 2)


def _rgb2bgr8(rgb: tuple[float, float, float]) -> tuple[int, int, int]:
    return tuple(int(v * 255 + 0.5) for v in rgb[::-1])


def color_cast(img_bgr: np.ndarray, gains_rgb: tuple[float, float, float]) -> np.ndarray:
    """선형 공간 채널 게인으로 광원 색 틀어짐 재현."""
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    lin = srgb_to_linear(rgb) * np.array(gains_rgb, np.float32)
    out = (linear_to_srgb(lin) * 255 + 0.5).astype(np.uint8)
    return cv2.cvtColor(out, cv2.COLOR_RGB2BGR)


# ---------------------------------------------------------------- 신체 장면

def _static_depth() -> np.ndarray:
    """벽 3.2m, 행거 옷 2.9m, 바닥(카메라 높이 1.6m 가정)."""
    depth = np.full((H, W), 3.2, np.float32)
    for y in range(int(H * 0.75), H):
        depth[y] = K["fy"] * 1.6 / max(y - K["cy"], 1)   # 3.5m 초과는 무효 처리됨
    depth[180:460, 40:160] = 2.9
    depth[180:460, 560:680] = 2.9
    return depth


def body_scene(seed: int = 0, n_frames: int = 6, person_z: float = 2.2):
    rng = np.random.default_rng(seed)
    img = np.full((H, W, 3), _rgb2bgr8((0.86, 0.80, 0.70)), np.uint8)      # 베이지 벽
    depth = _static_depth()
    label = np.zeros((H, W), np.uint8)
    img[int(H * 0.75):] = (120, 130, 140)                                  # 바닥

    # 행거에 걸린 옷 (배경, z=2.9m) — 파서가 'upper'로 오인식 [A5]
    for x0, col in ((40, (0.2, 0.3, 0.6)), (560, (0.6, 0.2, 0.2))):
        cv2.rectangle(img, (x0, 180), (x0 + 120, 460), _rgb2bgr8(col), -1)
        label[180:460, x0:x0 + 120] = 4

    # TV (반사 노이즈) [A7]
    img[120:260, 230:290] = (30, 30, 30)

    # 사람 (z=2.2m)
    cx = W // 2
    regions = [  # (cls, x1, y1, x2, y2, rgb)
        (2, cx - 45, 110, cx + 45, 150, (0.15, 0.1, 0.08)),     # hair
        (3, cx - 38, 140, cx + 38, 230, (0.85, 0.68, 0.58)),    # face
        (15, cx - 18, 230, cx + 18, 250, (0.85, 0.68, 0.58)),   # neck
        (4, cx - 110, 250, cx + 110, 520, (0.92, 0.92, 0.90)),  # upper (흰 셔츠)
        (8, cx - 150, 260, cx - 110, 500, (0.85, 0.68, 0.58)),  # arms
        (9, cx + 110, 260, cx + 150, 500, (0.85, 0.68, 0.58)),
        (6, cx - 100, 520, cx + 100, 840, (0.12, 0.15, 0.30)),  # lower (네이비 슬랙스)
        (12, cx - 100, 840, cx + 100, 880, (0.10, 0.08, 0.06)), # shoes
    ]
    for cls, x1, y1, x2, y2, rgb in regions:
        cv2.rectangle(img, (x1, y1), (x2 - 1, y2 - 1), _rgb2bgr8(rgb), -1)
        depth[y1:y2, x1:x2] = person_z + rng.normal(0, 0.005, (y2 - y1, x2 - x1))
        label[y1:y2, x1:x2] = cls

    # 셔츠 단추 디테일 (블러 점수 확보용 텍스처)
    for y in range(270, 510, 30):
        cv2.circle(img, (cx, y), 4, (60, 60, 60), -1)

    frames, dframes = [], []
    for i in range(n_frames):
        f = img.astype(np.int16) + rng.normal(0, 2, img.shape).astype(np.int16)
        frames.append(np.clip(f, 0, 255).astype(np.uint8))
        d = depth + rng.normal(0, 0.004, depth.shape).astype(np.float32)
        d[120:260, 230:290] = rng.uniform(0.6, 3.4, (140, 60))           # TV 반사
        d[rng.random(depth.shape) < 0.01] = 0                             # 산발적 결손
        dframes.append(d.astype(np.float32))
    # 블러 프레임 1장 섞기 [C3]
    frames[0] = cv2.GaussianBlur(frames[0], (21, 21), 8)

    box = PersonBox(cx - 160, 100, cx + 160, 890, 0.95)
    face = FaceBox(cx - 38, 140, cx + 38, 230)
    kps = np.zeros((17, 3), np.float32)
    pts = {0: (cx, 185), 5: (cx - 110, 260), 6: (cx + 110, 260), 7: (cx - 140, 380),
           8: (cx + 140, 380), 9: (cx - 145, 490), 10: (cx + 145, 490), 11: (cx - 60, 520),
           12: (cx + 60, 520), 13: (cx - 55, 680), 14: (cx + 55, 680), 15: (cx - 55, 840),
           16: (cx + 55, 840), 1: (cx - 15, 175), 2: (cx + 15, 175), 3: (cx - 35, 185),
           4: (cx + 35, 185)}
    for k, (x, y) in pts.items():
        kps[k] = (x, y, 0.9)
    return frames, dframes, label, box, face, kps


def empty_background_depth(seed: int = 1, n: int = 20) -> list[np.ndarray]:
    """사용자 없는 장면 (설치 시 배경 등록용)."""
    rng = np.random.default_rng(seed)
    base = _static_depth()
    out = []
    for _ in range(n):
        d = base + rng.normal(0, 0.004, base.shape).astype(np.float32)
        d[120:260, 230:290] = rng.uniform(0.6, 3.4, (140, 60))
        d[rng.random(base.shape) < 0.01] = 0
        out.append(d.astype(np.float32))
    return out


# ---------------------------------------------------------------- 촬영 매트

def mat_photo(garment_rgb=(0.12, 0.15, 0.30), cast=(1.25, 1.0, 0.75), seed: int = 0,
              mat: MatSpec | None = None, glossy: bool = False):
    """1mm/px 매트 렌더링 → 의류(티셔츠 형태) 배치 → 조명 색 틀어짐 → 원근 왜곡."""
    mat = mat or MatSpec()
    rng = np.random.default_rng(seed)
    mw, mh = int(mat.width_mm), int(mat.height_mm)
    img = np.full((mh, mw, 3), _rgb2bgr8(mat.background_rgb), np.uint8)
    d = cv2.aruco.getPredefinedDictionary(ARUCO_DICT)
    for i, c in mat.marker_corners_mm().items():
        x, y = c[0].astype(int)
        s = int(mat.marker_mm)
        m = cv2.aruco.generateImageMarker(d, i, s)
        img[y:y + s, x:x + s] = cv2.cvtColor(m, cv2.COLOR_GRAY2BGR)
    for p in mat.patches:
        cx, cy, r = int(p.center_mm[0]), int(p.center_mm[1]), int(p.size_mm / 2)
        img[cy - r:cy + r, cx - r:cx + r] = _rgb2bgr8(p.ref_rgb)
    # 티셔츠 실루엣
    tshirt = np.array([[350, 250], [650, 250], [800, 380], [720, 460], [650, 400], [650, 950],
                       [350, 950], [350, 400], [280, 460], [200, 380]], np.int32)
    cv2.fillPoly(img, [tshirt], _rgb2bgr8(garment_rgb))
    for y in range(300, 940, 24):                                 # 스트라이프 [D5]
        cv2.line(img, (360, y), (640, y), _rgb2bgr8(tuple(min(1, v + 0.25) for v in garment_rgb)), 3)
    if glossy:
        cv2.ellipse(img, (500, 600), (90, 160), 0, 0, 360, (250, 250, 250), -1)

    img = color_cast(img, cast)
    src = np.float32([[0, 0], [mw, 0], [mw, mh], [0, mh]])
    dst = np.float32([[120, 90], [1180, 140], [1230, 1420], [60, 1380]])
    Hm = cv2.getPerspectiveTransform(src, dst)
    photo = cv2.warpPerspective(img, Hm, (1300, 1500), borderValue=(60, 60, 60))
    noise = rng.normal(0, 1.5, photo.shape)
    return np.clip(photo + noise, 0, 255).astype(np.uint8)
