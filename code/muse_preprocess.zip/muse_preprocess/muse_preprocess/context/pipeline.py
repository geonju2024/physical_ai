"""상황 데이터(날씨·일정) 전처리 (제안서 5장). Cloud, 매일 06:00 + 버튼 트리거 시.

반복 일정 전개는 캘린더 API 옵션(구글 singleEvents=true 등)으로 받는다고 가정한다.
일정 원문은 라벨 추출 후 폐기하고, 추천에는 추출된 라벨만 쓴다 [I1].
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher

from ..common.types import Trace
from ..config import ContextConfig
from ..models.interfaces import TextLabeler

KST = timezone(timedelta(hours=9))

# 기본 약어 사전 (가정). 사용자별 사전이 우선한다 [F2]
DEFAULT_ABBREV = {
    "ㅁㅌ": "미팅", "mtg": "미팅", "ㅎㅅ": "회식", "ㅎㅇ": "회의", "ㅅㄱㅌ": "소개팅",
    "ㄱㅎ": "결혼식", "ㅇㄷ": "운동", "pt": "프레젠테이션", "ot": "오리엔테이션",
    "1on1": "면담", "1:1": "면담", "f/u": "후속 미팅", "w/": "함께",
}

# (키워드, 격식도, 활동성, 실외) — 격식도 1~5, 활동성 1~3
KEYWORD_RULES: list[tuple[str, int, int, bool]] = [
    ("결혼식", 5, 1, False), ("상견례", 5, 1, False), ("면접", 5, 1, False),
    ("발표", 4, 1, False), ("프레젠테이션", 4, 1, False), ("클라이언트", 4, 1, False),
    ("고객사", 4, 1, False), ("미팅", 4, 1, False), ("회의", 3, 1, False),
    ("면담", 3, 1, False), ("회식", 3, 1, False), ("소개팅", 4, 1, False),
    ("데이트", 3, 2, False), ("전시", 3, 2, False), ("오리엔테이션", 3, 1, False),
    ("출장", 4, 2, True), ("등산", 1, 3, True), ("운동", 1, 3, False),
    ("헬스", 1, 3, False), ("러닝", 1, 3, True), ("캠핑", 1, 3, True),
    ("피크닉", 2, 2, True), ("산책", 2, 2, True), ("골프", 2, 3, True),
]


@dataclass
class Event:
    source: str
    title: str
    start: datetime
    end: datetime
    all_day: bool = False
    location: str = ""
    sources: list[str] = field(default_factory=list)


@dataclass
class EventLabel:
    event_id: str            # 원문 대신 해시만 보관
    start: datetime
    end: datetime
    formality: int
    activity: int
    outdoor: bool
    confidence: float
    ask_user: bool
    resolved_by: str         # rule | llm | default


@dataclass
class ContextFeatures:
    date: str
    feels_like_min: float | None
    feels_like_max: float | None
    temp_range: float | None
    max_pop: float | None
    pm10_max: float | None
    exposure_weight: float
    layering_needed: bool
    max_formality: int
    max_activity: int
    events: list[EventLabel]
    trace: Trace


# ---------------------------------------------------------------- 날씨

def feels_like(temp_c: float, wind_ms: float, humidity: float) -> float:
    """기상청 체감온도식 단순화: 10℃ 이하·풍속 1.3m/s 이상은 바람냉각, 그 외 기온 그대로."""
    v = wind_ms * 3.6
    if temp_c <= 10 and wind_ms >= 1.3:
        return round(13.12 + 0.6215 * temp_c - 11.37 * v**0.16 + 0.3965 * v**0.16 * temp_c, 1)
    if temp_c >= 27 and humidity >= 40:
        # Steadman 근사 (여름)
        e = humidity / 100 * 6.105 * 2.718281828 ** (17.27 * temp_c / (237.7 + temp_c))
        return round(temp_c + 0.33 * e - 0.70 * wind_ms - 4.0, 1)
    return float(temp_c)


def fill_forecast(hours: list[dict], prev: list[dict] | None) -> tuple[list[dict], bool]:
    """결측 시간은 직전 예보 값으로 대체 [H2]."""
    prev_map = {h["time"]: h for h in (prev or [])}
    out, imputed = [], False
    for h in hours:
        h = dict(h)
        for k in ("temp", "wind", "humidity", "pop", "pm10"):
            if h.get(k) is None and h["time"] in prev_map and prev_map[h["time"]].get(k) is not None:
                h[k], imputed = prev_map[h["time"]][k], True
        out.append(h)
    return out, imputed


# ---------------------------------------------------------------- 캘린더

def to_event(raw: dict, source: str) -> Event:
    """구글/네이버 응답을 공통 스키마로. 시간은 KST로 통일."""
    def parse(v) -> tuple[datetime, bool]:
        if isinstance(v, dict):
            if "date" in v:
                return datetime.fromisoformat(v["date"]).replace(tzinfo=KST), True
            v = v.get("dateTime")
        dt = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return (dt.replace(tzinfo=KST) if dt.tzinfo is None else dt.astimezone(KST)), False
    s, all_day = parse(raw["start"])
    e, _ = parse(raw["end"])
    return Event(source, raw.get("summary") or raw.get("title") or "", s, e, all_day,
                 raw.get("location", ""), [source])


def _overlap_ratio(a: Event, b: Event) -> float:
    inter = (min(a.end, b.end) - max(a.start, b.start)).total_seconds()
    shorter = min((a.end - a.start).total_seconds(), (b.end - b.start).total_seconds())
    return max(inter, 0) / shorter if shorter > 0 else float(a.start == b.start)


def merge_duplicates(events: list[Event], cfg: ContextConfig,
                     user_abbrev: dict[str, str] | None = None) -> list[Event]:
    """[F1] 구글·네이버에 같은 일정이 있으면 병합. 약어를 풀어 비교한다 ("A사 ㅁㅌ" = "A사 미팅")."""
    merged: list[Event] = []
    norm = lambda t: normalize_title(t, user_abbrev or {}).replace(" ", "")
    for ev in sorted(events, key=lambda e: e.start):
        for m in merged:
            sim = SequenceMatcher(None, norm(m.title), norm(ev.title)).ratio()
            if sim >= cfg.title_sim_merge and _overlap_ratio(m, ev) >= cfg.overlap_merge:
                m.sources = sorted(set(m.sources + ev.sources))
                m.location = m.location or ev.location
                break
        else:
            merged.append(ev)
    return merged


def normalize_title(title: str, user_abbrev: dict[str, str]) -> str:
    t = title.strip()
    for table in (user_abbrev, DEFAULT_ABBREV):          # 사용자 사전 우선
        for k in sorted(table, key=len, reverse=True):
            t = re.sub(re.escape(k), table[k], t, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", t)


def rule_label(text: str) -> tuple[int, int, bool, float] | None:
    hits = [r for r in KEYWORD_RULES if r[0] in text]
    if not hits:
        return None
    f = max(h[1] for h in hits)
    a = max(h[2] for h in hits)
    o = any(h[3] for h in hits)
    return f, a, o, 0.9 if len(hits) == 1 else 0.8


# ---------------------------------------------------------------- 파이프라인

class ContextPipeline:
    def __init__(self, cfg: ContextConfig, labeler: TextLabeler):
        self.cfg, self.labeler = cfg, labeler

    def label_event(self, ev: Event, user_abbrev: dict[str, str]) -> EventLabel:
        cfg = self.cfg
        text = normalize_title(ev.title, user_abbrev)
        eid = hashlib.sha256(f"{ev.start.isoformat()}|{ev.title}".encode()).hexdigest()[:16]
        r = rule_label(text)
        if r and r[3] >= cfg.label_conf_min:
            return EventLabel(eid, ev.start, ev.end, r[0], r[1], r[2], r[3], False, "rule")
        out = self.labeler.label(text)                 # 사전으로 안 풀리는 표현만 LLM 호출
        if out.get("confidence", 0) >= cfg.label_conf_min:
            return EventLabel(eid, ev.start, ev.end, int(out["formality"]), int(out["activity"]),
                              bool(out["outdoor"]), float(out["confidence"]), False, "llm")
        return EventLabel(eid, ev.start, ev.end, cfg.default_formality, 2, False,
                          float(out.get("confidence", 0)), True, "default")   # "어떤 자리예요?"

    def run(self, day: datetime, forecast: list[dict], fetched_at: datetime,
            raw_events: list[tuple[str, dict]], *, transport: str = "transit",
            indoor_temp_c: float = 22.0, prev_forecast: list[dict] | None = None,
            user_abbrev: dict[str, str] | None = None,
            now: datetime | None = None) -> ContextFeatures:
        cfg, tr = self.cfg, Trace()
        day = day.astimezone(KST)
        with tr.stage("05_06_calendar"):
            events = [to_event(r, src) for src, r in raw_events]
            events = [e for e in events if e.start.date() == day.date()]
            events = merge_duplicates(events, cfg, user_abbrev)
        with tr.stage("07_08_labels"):
            labels = [self.label_event(e, user_abbrev or {}) for e in events]
        with tr.stage("01_02_weather"):
            now = (now or datetime.now(KST)).astimezone(KST)
            if (now - fetched_at.astimezone(KST)).total_seconds() / 3600 > cfg.forecast_stale_h:
                tr.flag("forecast_stale")              # 재요청 필요
            hours, imputed = fill_forecast(forecast, prev_forecast)
            if imputed:
                tr.flag("forecast_imputed")
            timed = [e for e in events if not e.all_day]
            if timed:
                start = min(e.start for e in timed) - timedelta(hours=cfg.pre_event_buffer_h)
                end = max(e.end for e in timed)
            else:
                start, end = day.replace(hour=8), day.replace(hour=20)
            window = [h for h in hours
                      if start <= datetime.fromisoformat(h["time"]).replace(tzinfo=KST) <= end] or hours
            fl = [feels_like(h["temp"], h.get("wind") or 0, h.get("humidity") or 50)
                  for h in window if h.get("temp") is not None]
            temps = [h["temp"] for h in window if h.get("temp") is not None]
            pops = [h["pop"] for h in window if h.get("pop") is not None]
            pms = [h["pm10"] for h in window if h.get("pm10") is not None]
        with tr.stage("03_04_exposure_layering"):
            outdoor_any = any(l.outdoor for l in labels)
            w = cfg.exposure_weight.get(transport, 1.0)
            if outdoor_any:
                w = max(w, 1.0)                        # 실외 일정이 있으면 이동수단과 무관
            layering = bool(fl) and abs(min(fl) - indoor_temp_c) >= cfg.layering_temp_gap_c

        return ContextFeatures(
            day.date().isoformat(),
            min(fl) if fl else None, max(fl) if fl else None,
            (max(temps) - min(temps)) if temps else None,
            max(pops) if pops else None, max(pms) if pms else None,
            w, layering,
            max((l.formality for l in labels), default=cfg.default_formality),
            max((l.activity for l in labels), default=1),
            labels, tr)
