"""합성 데이터 기반 통합 테스트. 가구 001의 어려운 조건에서 각 전처리 단계가 의도대로 동작하는지 검증."""
from datetime import datetime, timedelta

import numpy as np
import pytest

from muse_preprocess import MuseConfig, RetakeRequired
from muse_preprocess import synthetic as S
from muse_preprocess.body.pipeline import BodyPipeline, DeviceCalibration, SensorReading
from muse_preprocess.catalog.pipeline import (CatalogPipeline, Product, ProductImage,
                                              normalize_size_table)
from muse_preprocess.common import color as C
from muse_preprocess.common.quality import select_frames
from muse_preprocess.context.pipeline import KST, ContextPipeline, normalize_title
from muse_preprocess.depth.pipeline import BackgroundDepthModel, DepthPipeline, Intrinsics
from muse_preprocess.feedback.pipeline import EdgeEventQueue, FeedbackEvent, FeedbackPipeline
from muse_preprocess.models.baselines import (BorderTypeClassifier, ColorHistEmbedder,
                                              FixedFace, FixedParser, FixedPersonDetector,
                                              FixedPose, MatBackgroundSegmenter, NullLabeler)
from muse_preprocess.wardrobe.pipeline import FlatlayPipeline, WardrobeItem, match_worn

CFG = MuseConfig()
KI = Intrinsics(**S.K)


@pytest.fixture(scope="module")
def scene():
    return S.body_scene(seed=0)


@pytest.fixture(scope="module")
def depth_result(scene):
    _, dframes, *_ = scene
    bg = BackgroundDepthModel.fit(S.empty_background_depth(), CFG.depth)
    return bg, DepthPipeline(CFG.depth, bg, KI).run(dframes)


def make_body(scene, user_faces=None, face_emb=None):
    frames, dframes, label, box, face, kps = scene
    cam = np.array([[S.K["fx"], 0, S.K["cx"]], [0, S.K["fy"], S.K["cy"]], [0, 0, 1]])
    calib = DeviceCalibration(cam, np.zeros(5))
    emb = face_emb if face_emb is not None else np.ones(8) / np.sqrt(8)
    return BodyPipeline(CFG, calib, FixedPersonDetector([box]), FixedParser(label),
                        FixedPose(kps), FixedFace(face, emb),
                        user_faces if user_faces is not None else {"jieun": [emb]})


SENSOR = SensorReading(tof_distance_m=2.2, lux=500, cct=5000, led_lux=450)


# ---------------------------------------------------------------- 공통

def test_quality_gate_drops_blurred_frame(scene):
    frames = scene[0]
    idx = select_frames(frames, CFG.quality, 3)
    assert 0 not in idx and len(idx) == 3


def test_motion_detected(scene):
    import cv2
    f = scene[0][1]
    moved = cv2.warpAffine(f, np.float32([[1, 0, 12], [0, 1, 0]]), (f.shape[1], f.shape[0]))
    from muse_preprocess.common.quality import motion_score
    assert motion_score(f, scene[0][2]) < CFG.quality.motion_max < motion_score(f, moved)


def test_ccm_recovers_cast():
    ref = np.array([[0.9, 0.9, 0.9], [0.5, 0.5, 0.5], [0.2, 0.2, 0.2],
                    [0.7, 0.2, 0.2], [0.2, 0.6, 0.2], [0.2, 0.3, 0.7]])
    gains = np.array([1.3, 1.0, 0.7])
    measured = C.linear_to_srgb(C.srgb_to_linear(ref) * gains)
    ccm = C.estimate_ccm(measured, ref)
    fixed = C.linear_to_srgb(C.srgb_to_linear(measured) @ ccm.T)
    assert C.patch_delta_e(fixed, ref).mean() < 1.0


def test_adaptation_identity_at_d65():
    assert np.allclose(C.adaptation_matrix(6504), np.eye(3), atol=0.02)


# ---------------------------------------------------------------- 깊이

def test_depth_reflection_and_foreground(depth_result):
    bg, res = depth_result
    assert bg.reflective[150:250, 240:280].mean() > 0.9          # TV 반사 영역 상시 마스크
    assert np.isnan(res.depth[150:250, 240:280]).mean() > 0.9
    fg = res.foreground
    assert fg[300:500, 300:420].mean() > 0.95                    # 사람 몸통
    assert fg[200:440, 50:150].mean() < 0.01                     # 행거 옷은 전경 아님
    assert res.body_valid_ratio > 0.95


def test_depth_floor_and_pointcloud(depth_result):
    _, res = depth_result
    assert res.floor_plane is not None
    assert abs(res.pitch_deg) < 2.0
    assert len(res.points) > 1000


def test_depth_desync():
    bg = BackgroundDepthModel.fit(S.empty_background_depth(n=5), CFG.depth)
    with pytest.raises(RetakeRequired):
        DepthPipeline(CFG.depth, bg, KI).run(S.empty_background_depth(n=3),
                                             rgb_ts_ms=0, depth_ts_ms=25)


# ---------------------------------------------------------------- 신체

def test_body_daily_removes_background_garments(scene, depth_result):
    _, res_d = depth_result
    out = make_body(scene).run(scene[0], SENSOR, depth=res_d.depth, mode="daily")
    assert out.user_id == "jieun" and out.id_status == "auto"
    assert out.parse_map[200:440, 50:150].max() == 0              # 오인식 라벨 제거 [A5]
    assert out.trace.flags["depth_gate_removed_ratio"] > 0.1
    assert {"upper", "lower", "shoes"} <= set(out.garments)
    assert out.vton_input.shape == (1024, 768, 3)
    assert out.trace.trainable


def test_body_face_is_masked(scene, depth_result):
    _, res_d = depth_result
    out = make_body(scene).run(scene[0], SENSOR, depth=res_d.depth)
    face = out.face_box
    region = out.color_img.copy()
    region[~out.person_mask] = 255
    masked = make_body(scene).anonymize(region, face)
    assert (masked[face.y1:face.y2, face.x1:face.x2] == 128).all()


def test_body_measure_mode(scene, depth_result):
    _, res_d = depth_result
    out = make_body(scene).run(scene[0], SENSOR, depth=res_d.depth, mode="measure")
    assert out.keypoints is not None
    assert out.measurement["footwear_offset_cm"] == 3.0          # 신발 감지 → 운동화 가정
    assert out.trace.flags.get("guide_barefoot")


def test_body_distance_and_guest(scene, depth_result):
    _, res_d = depth_result
    with pytest.raises(RetakeRequired) as e:
        make_body(scene).run(scene[0], SensorReading(1.2, 500, 5000, 450), depth=res_d.depth)
    assert e.value.reason == "too_close"
    other = np.ones(8); other[0] = -5
    registered = {"jieun": [np.ones(8) / np.sqrt(8)]}
    out = make_body(scene, user_faces=registered, face_emb=other / np.linalg.norm(other)).run(
        scene[0], SENSOR, depth=res_d.depth)
    assert out.id_status == "guest" and not out.trace.trainable  # 개인 학습 제외 [C6]


def test_body_ambient_light_flag(scene, depth_result):
    _, res_d = depth_result
    out = make_body(scene).run(scene[0], SensorReading(2.2, 900, 3000, 400), depth=res_d.depth)
    assert out.trace.flags["color_low_confidence"]


# ---------------------------------------------------------------- 옷장

def flatlay():
    return FlatlayPipeline(CFG.wardrobe, CFG.color, MatBackgroundSegmenter(), ColorHistEmbedder())


def test_flatlay_color_and_measure():
    res = flatlay().run(S.mat_photo(), wardrobe=[])
    assert res.ccm_delta_e < CFG.color.flatlay_ccm_max_delta_e
    true_lab = C.bgr8_to_lab(np.uint8([[[77, 38, 31]]]))[0, 0]   # (0.12,0.15,0.30) 네이비
    de = C.patch_delta_e(np.array([C.lab2rgb(np.array(res.colors[0]["lab"]).reshape(1, 1, 3)).ravel()]),
                         np.array([[0.12, 0.15, 0.30]]))[0]
    assert de < 10, (res.colors, true_lab)
    assert 650 < res.measures_mm["length_mm"] < 750              # 실제 700mm
    assert max(res.image.shape[:2]) <= CFG.wardrobe.min_long_side
    assert res.detail_crop.shape[:2] == (512, 512)


def test_flatlay_duplicate_and_glossy():
    p = flatlay()
    first = p.run(S.mat_photo(seed=1), wardrobe=[])
    item = WardrobeItem("navy-tee", first.embedding, first.colors, first.measures_mm)
    second = p.run(S.mat_photo(seed=2), wardrobe=[item])
    assert second.duplicate and second.duplicate["action"] == "confirm_same"
    glossy = p.run(S.mat_photo(seed=3, glossy=True), wardrobe=[])
    assert glossy.attributes.get("glossy")
    # 하이라이트는 색 추출에서 빠지므로 대표색은 여전히 네이비
    assert glossy.colors[0]["hex"] == first.colors[0]["hex"] or \
        C.patch_delta_e(np.array([[0.12, 0.15, 0.30]]),
                        np.array([C.lab2rgb(np.array(glossy.colors[0]["lab"]).reshape(1, 1, 3)).ravel()]))[0] < 10


def test_flatlay_white_and_black_garments():
    p = flatlay()
    for rgb in ((0.95, 0.95, 0.94), (0.06, 0.06, 0.07)):          # [D4] 무채색
        res = p.run(S.mat_photo(garment_rgb=rgb, seed=4), wardrobe=[])
        assert 650 < res.measures_mm["length_mm"] < 750
        assert res.attributes["achromatic"]


def test_flatlay_rejects_blur():
    import cv2
    with pytest.raises(RetakeRequired) as e:
        flatlay().run(cv2.GaussianBlur(S.mat_photo(), (0, 0), 3), wardrobe=[])
    assert e.value.reason == "blur"


def test_flatlay_requires_markers():
    img = S.mat_photo()
    img[:, :] = 128
    with pytest.raises(RetakeRequired):
        flatlay().run(img, wardrobe=[])


def test_worn_matching(scene, depth_result):
    _, res_d = depth_result
    out = make_body(scene).run(scene[0], SENSOR, depth=res_d.depth)
    emb = ColorHistEmbedder()
    g = out.garments["upper"]
    lab = C.bgr8_to_lab(g.image)[g.mask]
    item = WardrobeItem("white-shirt", emb.embed(g.image, g.mask.astype(np.float32)),
                        C.dominant_colors(lab, None, (2, 3)), {})
    matches = {m.garment_cls: m for m in match_worn(out.garments, [item], emb,
                                                    CFG.wardrobe, CFG.color)}
    assert matches["upper"].action == "auto_worn"
    assert matches["lower"].action != "auto_worn"


# ---------------------------------------------------------------- 쇼핑몰

def test_catalog_pipeline():
    cut = np.full((600, 450, 3), 255, np.uint8)
    cut[100:500, 100:350] = (60, 40, 30)                         # 네이비 계열
    p = Product("P1", [ProductImage("a", cut), ProductImage("b", cut.copy())],
                {"color": "네이비", "material": None},
                size_table={"m": {"가슴단면": "52cm", "총장": "70", "어깨너비": "18 inch"}})
    res = CatalogPipeline(CFG.catalog, CFG.color, BorderTypeClassifier(), ColorHistEmbedder(),
                          autotagger=lambda img: {"material": ("cotton", 0.9)}).run(p)
    assert res.vton_ready and res.vton_image.shape == (1024, 768, 3)
    assert res.trace.flags.get("upscaled")                        # 600px < 768
    assert res.sizes_cm["M"] == {"chest": 104.0, "length": 70.0, "shoulder": 45.7}
    assert res.meta["material"] == "cotton" and res.meta_source["material"] == "ai"


def test_size_table_units():
    assert normalize_size_table({"L": {"허리 단면": "400mm"}})["L"]["waist"] == 80.0


# ---------------------------------------------------------------- 상황

def test_context_pipeline():
    day = datetime(2026, 10, 8, 7, 0, tzinfo=KST)
    forecast = [{"time": f"2026-10-08T{h:02d}:00", "temp": 6 + h * 0.5, "wind": 4,
                 "humidity": 60, "pop": 60 if h > 12 else 10, "pm10": 30} for h in range(6, 22)]
    forecast[5]["temp"] = None
    prev = [{"time": "2026-10-08T11:00", "temp": 11.0}]
    events = [("google", {"summary": "A사 ㅁㅌ", "start": {"dateTime": "2026-10-08T14:00:00+09:00"},
                          "end": {"dateTime": "2026-10-08T15:00:00+09:00"}}),
              ("naver", {"title": "A사 미팅", "start": "2026-10-08T14:00:00",
                         "end": "2026-10-08T15:30:00"}),
              ("google", {"summary": "ㅋㅋ 약속", "start": {"dateTime": "2026-10-08T19:00:00+09:00"},
                          "end": {"dateTime": "2026-10-08T21:00:00+09:00"}})]
    res = ContextPipeline(CFG.context, NullLabeler()).run(
        day, forecast, day - timedelta(hours=1), events, transport="transit",
        indoor_temp_c=23.0, prev_forecast=prev, now=day)
    assert len(res.events) == 2                                   # 구글·네이버 중복 병합
    assert res.max_formality == 4
    assert any(e.ask_user for e in res.events)                    # 해석 불가 약어
    assert res.trace.flags.get("forecast_imputed")
    assert res.max_pop == 60 and res.layering_needed


def test_abbrev_user_first():
    assert normalize_title("ㄱㅅ 미팅", {"ㄱㅅ": "고객사"}) == "고객사 미팅"


# ---------------------------------------------------------------- 피드백

def test_feedback_pipeline(tmp_path):
    q = EdgeEventQueue(str(tmp_path / "q.db"))
    now = 1_800_000_000.0
    base = dict(device_id="d1", household_id="h1", user_id="jieun", id_conf=0.9)
    evs = [
        FeedbackEvent("e1", type="impression", ts_device=now - 100, outfit_id="o1",
                      position="B", propensity=0.2, **base),
        FeedbackEvent("e2", type="like", ts_device=now - 90, outfit_id="o1", **base),
        FeedbackEvent("e3", type="like", ts_device=now - 89.5, outfit_id="o1", **base),  # 연타
        FeedbackEvent("e4", type="uncomfortable", ts_device=now - 80, item_ids=["shoe1"], **base),
        FeedbackEvent("e5", type="skip", ts_device=now - 70, outfit_id="o2", reason="laundry", **base),
        FeedbackEvent("e6", type="worn", ts_device=now - 60, outfit_id="o1", position="B",
                      propensity=0.2, **base),
        FeedbackEvent("e7", type="like", ts_device=now - 50, outfit_id="o3",
                      **{**base, "user_id": "kid", "id_conf": 0.3}),          # 식별 불확실
    ]
    for e in evs:
        q.enqueue(e)
    q.enqueue(evs[1])                                             # 재전송 중복
    sent = q.pending()
    for e in sent:
        e.ts_server = e.sent_at_device + 30                       # 기기 시계 30초 느림
    out = FeedbackPipeline(CFG.feedback).run(sent + [sent[1]], now=now)
    q.ack([e.event_id for e in sent])
    assert q.pending() == []
    ids = {r.source_event for r in out.rows}
    assert "e3" not in ids and "e5" not in ids and "e7" not in ids
    assert [e.event_id for e in out.household_only] == ["e7"]
    shoe = [r for r in out.rows if r.target_id == "shoe1"][0]
    assert shoe.target == "item" and shoe.label < -0.9
    worn = [r for r in out.rows if r.source_event == "e6"][0]
    assert worn.label == pytest.approx(0.8 * 5, rel=0.01)         # IPS 1/0.2
    assert out.trace.flags.get("clock_skew:d1") == pytest.approx(30, abs=1)
