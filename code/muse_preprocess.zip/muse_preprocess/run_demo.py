"""합성 데이터로 6개 전처리 파이프라인을 모두 실행하고 단계별 시간·품질 플래그를 출력한다.

    python run_demo.py                 # 기본 파라미터
    python run_demo.py --config household_001.yaml
"""
from __future__ import annotations

import argparse
import tempfile
from datetime import datetime, timedelta

import cv2
import numpy as np

from muse_preprocess import MuseConfig, RetakeRequired
from muse_preprocess import synthetic as S
from muse_preprocess.body.pipeline import BodyPipeline, DeviceCalibration, SensorReading
from muse_preprocess.catalog.pipeline import CatalogPipeline, Product, ProductImage
from muse_preprocess.context.pipeline import KST, ContextPipeline
from muse_preprocess.depth.pipeline import BackgroundDepthModel, DepthPipeline, Intrinsics
from muse_preprocess.feedback.pipeline import EdgeEventQueue, FeedbackEvent, FeedbackPipeline
from muse_preprocess.models.baselines import (BorderTypeClassifier, ColorHistEmbedder, FixedFace,
                                              FixedParser, FixedPersonDetector, FixedPose,
                                              MatBackgroundSegmenter, NullLabeler)
from muse_preprocess.wardrobe.pipeline import FlatlayPipeline, WardrobeItem, match_worn


def report(title: str, trace, extra: dict | None = None) -> None:
    print(f"\n== {title}  (합계 {trace.total_ms:.0f} ms, 학습 사용 {'O' if trace.trainable else 'X'})")
    for k, v in trace.timings_ms.items():
        print(f"   {k:<26}{v:8.1f} ms")
    if trace.flags:
        print("   flags:", trace.flags)
    for k, v in (extra or {}).items():
        print(f"   {k}: {v}")


def main(cfg: MuseConfig) -> None:
    # 2. 깊이 -----------------------------------------------------------
    frames, dframes, label, box, face, kps = S.body_scene()
    bg = BackgroundDepthModel.fit(S.empty_background_depth(), cfg.depth)
    K = Intrinsics(**S.K)
    dres = DepthPipeline(cfg.depth, bg, K).run(dframes)
    report("2. 깊이 (측정 모드, 점군 포함)", dres.trace,
           {"body_valid_ratio": round(dres.body_valid_ratio, 3), "points": len(dres.points),
            "pitch_deg": dres.pitch_deg})
    d_daily = DepthPipeline(cfg.depth, bg, K).run(dframes, build_points=False)
    report("2. 깊이 (일상 모드, 점군 생략)", d_daily.trace)

    # 1. 신체 RGB -------------------------------------------------------
    cam = np.array([[S.K["fx"], 0, S.K["cx"]], [0, S.K["fy"], S.K["cy"]], [0, 0, 1]])
    emb = np.ones(8) / np.sqrt(8)
    body = BodyPipeline(cfg, DeviceCalibration(cam, np.zeros(5)), FixedPersonDetector([box]),
                        FixedParser(label), FixedPose(kps), FixedFace(face, emb), {"jieun": [emb]})
    body.warmup()
    sensor = SensorReading(tof_distance_m=2.2, lux=480, cct=4200, led_lux=420)
    bres = body.run(frames, sensor, depth=d_daily.depth, mode="daily")
    report("1. 신체 RGB (일상 모드)", bres.trace,
           {"user": (bres.user_id, bres.id_status), "garments": list(bres.garments),
            "vton_input": bres.vton_input.shape})
    try:
        body.run(frames, SensorReading(1.4, 480, 4200, 420), depth=d_daily.depth)
    except RetakeRequired as e:
        print(f"   재촬영 안내 예시: '{e}' ({e.reason})")

    # 3. 옷장 -----------------------------------------------------------
    flat = FlatlayPipeline(cfg.wardrobe, cfg.color, MatBackgroundSegmenter(), ColorHistEmbedder())
    fres = flat.run(S.mat_photo(), wardrobe=[])
    report("3-A. 옷장 펼침 촬영", fres.trace,
           {"colors": [c["hex"] for c in fres.colors], "measures_mm": fres.measures_mm,
            "attributes": fres.attributes})
    g = bres.garments["upper"]
    from muse_preprocess.common import color as C
    item = WardrobeItem("white-shirt", ColorHistEmbedder().embed(g.image, g.mask.astype(np.float32)),
                        C.dominant_colors(C.bgr8_to_lab(g.image)[g.mask], None, (2, 3)), {})
    for m in match_worn(bres.garments, [item], ColorHistEmbedder(), cfg.wardrobe, cfg.color):
        print(f"   3-B. 착용 매칭 {m.garment_cls:<6} → {m.action} ({m.similarity})")

    # 4. 쇼핑몰 ---------------------------------------------------------
    cut = np.full((640, 480, 3), 255, np.uint8)
    cv2.rectangle(cut, (120, 100), (360, 560), (60, 40, 30), -1)
    p = Product("P-1001", [ProductImage("main.jpg", cut)], {"color": "네이비", "material": ""},
                size_table={"M": {"가슴단면": "52cm", "총장": "70cm"}})
    cres = CatalogPipeline(cfg.catalog, cfg.color, BorderTypeClassifier(), ColorHistEmbedder()).run(p)
    report("4. 쇼핑몰 상품", cres.trace,
           {"vton_ready": cres.vton_ready, "sizes_cm": cres.sizes_cm,
            "color_confidence": cres.color_confidence})

    # 5. 상황 -----------------------------------------------------------
    day = datetime(2026, 10, 8, 6, 0, tzinfo=KST)
    fc = [{"time": f"2026-10-08T{h:02d}:00", "temp": 8 + h * 0.4, "wind": 3, "humidity": 55,
           "pop": 60 if h >= 15 else 20, "pm10": 40} for h in range(6, 23)]
    evs = [("google", {"summary": "A사 ㅁㅌ", "start": {"dateTime": "2026-10-08T14:00:00+09:00"},
                       "end": {"dateTime": "2026-10-08T15:00:00+09:00"}}),
           ("naver", {"title": "A사 미팅", "start": "2026-10-08T14:00:00", "end": "2026-10-08T15:00:00"})]
    xres = ContextPipeline(cfg.context, NullLabeler()).run(day, fc, day - timedelta(hours=1), evs, now=day)
    report("5. 상황 데이터", xres.trace,
           {"formality": xres.max_formality, "feels_like": (xres.feels_like_min, xres.feels_like_max),
            "max_pop": xres.max_pop, "layering": xres.layering_needed, "events": len(xres.events)})

    # 6. 피드백 ---------------------------------------------------------
    with tempfile.TemporaryDirectory() as tmp:
        q = EdgeEventQueue(f"{tmp}/queue.db")
        now = datetime(2026, 10, 8, 8, 0, tzinfo=KST).timestamp()
        base = dict(device_id="mirror-001", household_id="h001", user_id="jieun", id_conf=0.92)
        for i, (t, extra) in enumerate([("impression", {"outfit_id": "o1", "position": "main", "propensity": 0.6}),
                                        ("like", {"outfit_id": "o1"}),
                                        ("worn", {"outfit_id": "o1", "position": "main", "propensity": 0.6}),
                                        ("uncomfortable", {"item_ids": ["shoe-7"]}),
                                        ("skip", {"outfit_id": "o2", "reason": "mood"})]):
            q.enqueue(FeedbackEvent(f"ev{i}", type=t, ts_device=now - 60 + i * 5, **base, **extra))
        sent = q.pending()
        for e in sent:
            e.ts_server = e.sent_at_device
        out = FeedbackPipeline(cfg.feedback).run(sent, now=now)
        q.ack([e.event_id for e in sent])
    report("6. 행동·피드백", out.trace,
           {"rows": [(r.target, r.target_id, r.label) for r in out.rows]})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config")
    args = ap.parse_args()
    main(MuseConfig.from_yaml(args.config) if args.config else MuseConfig())
